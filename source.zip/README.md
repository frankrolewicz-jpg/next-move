# Next Move — Frank's personal chess coach

A local-first React/TypeScript/Vite PWA built from **1,049 actual rapid games**, with **362 Stockfish-verified lessons**. No account, backend, paid inference, or paid runtime service. Deployment target: static Cloudflare Pages.

The supplied file was `data/all_chess_games.rtf`. The original is untouched. Its text was converted to `data/all_chess_games.pgn` and every game replayed legally. Username: **Frankrolewicz**. Latest recorded rating: **765**; peak: **964**. See [the historical assessment](docs/HISTORY_REPORT.md), [validation JSON](data/validation-report.json), and [full rating CSV](data/rating-history.csv).

## Run locally

Use Node 22.12+ or Node 24 (tested with 24.20.0).

```sh
npm ci
npm run dev
```

Open the printed loopback address, normally `http://127.0.0.1:5173`. The dev server deliberately binds only to this Mac. For offline/PWA behavior, use the production build:

```sh
npm run build
npm run preview -- --port 5173
```

Stop the dev server before starting preview on the same port. Offline installation occurs only in production builds, after the first successful online load. Wait for **Offline ready**. Service-worker updates activate after existing app tabs close, preserving a consistent cached version. Cache matching ignores Vary for this application's same-origin static assets so Vite's Origin-dependent response headers do not break offline module loading.

## What the MVP does

- Daily 20-minute timer with recall, focused practice, and reflection guidance. Time counts only while Practice is open and the document is visible.
- Your latest 150 rapid games determine current weaknesses. Thirty evenly spaced older games supply comparison lessons; all 1,049 games supply the rating history.
- Touch/click/drag board input, keyboard SAN entry, and promotion selection.
- Attempt before answer, three escalating hints, locally checked alternative moves, explanations tied to legal engine lines, and forward/back continuation replay.
- Stockfish 17.1 lite single-threaded WASM in a Web Worker; serialized UCI calls, timeouts and cancellation. All engine files are served locally, not from a CDN.
- Repetition: failed/revealed cards return in 10 minutes; successful cards begin at 1 day and grow to 30 days. Three successful **spaced** reviews establish mastery. Early manual revisits do not increase mastery. Practice lapses increase topic priority.
- IndexedDB saves games, lessons, completed analysis, schedules and sessions. Export/restore JSON backups from My games. Restore revalidates PGNs and restores schedules/sessions; non-bundled lessons are regenerated through Analyze instead of trusting imported engine evaluations.
- Completed-game PGN import, deduplication and reporting of rejected records. No arbitrary FEN analysis screen and no live-game endpoint.
- Optional Chess.com sync on app launch, foreground resume or reconnection, at most every six hours; a manual Sync button is also available. First sync reconciles the last two months; later syncs catch up from the last successful sync. Sequential archive requests, network timeout, graceful error and local PGN fallback. Analyze unreviewed games generates new local lessons in batches of up to 150.
- Home-screen manifest, maskable icons, local assets, offline cache and iPhone instructions.

## Evidence and limits

Screening covers 5,584 player decisions in 180 games, at depth 8. At most three candidate errors per game are rechecked at depth 12; 362 survive. Positions already worse than -4.0 are excluded. The threshold is 1.4 pawn-equivalents of loss; mate uses a separate ordering value. Explanation facts come from chess.js and stored engine principal variations. Equal exchanges are not automatically labeled material loss. Development and open-file rook labels require explicit board facts; generic opening/endgame labels describe phase only. No invented forks, pins or unsupported positional claims.

Depth 12 with the small network is finite search, not proof of a unique move. Scores are from the player's perspective. FEN analysis does not reconstruct repetition history. Screening can miss subtler mistakes, and the three-position cap means theme counts are **selected lesson counts, not comprehensive error rates**. The 30-game older engine sample is descriptive, not a controlled trend estimate. Ratings are PGN header ratings and may precede the post-game update. Some games only have EndTime, limiting precise within-day chronology.

The 20-minute program provides phase guidance; it is not a full curriculum of multi-move exercises. Current lessons ask for one move, then let you replay the continuation. Elo 1400 is the goal, not a promised result.

The app does not run while closed on iPhone. Automatic sync therefore occurs on opening, not as a reliable background task. Browser storage can be evicted; use backups. Personal practice progress stays in IndexedDB. **The bundled seed games and lesson evidence would be accessible at public static URLs if deployed**; there is no v1 authentication. Newly imported games and practice records are not uploaded.

## Verification

```sh
npm run validate:pgn
npm test
npm run typecheck
npm run build
# With the production preview already running on port 5173:
npm run test:e2e
```

The browser tests use local Chrome on macOS. Elsewhere, install Playwright Chromium with `npx playwright install chromium`, or set `PLAYWRIGHT_CHROME_EXECUTABLE_PATH`.

Verified locally:

- 1,049 PGNs replayed; 0 duplicates; 0 illegal/rejected records.
- 14 unit/integration tests: parsing, results, deduplication, ratings, all lesson source positions and full principal variations, UCI parsing/serialization, scheduling, early-review mastery protection, IndexedDB and backup rejection.
- 5 Chromium browser tests: iPhone-sized layout, actual local WASM evaluation, hints/answer/replay, reload persistence, offline reload **and offline WASM evaluation**, PGN import/live-game rejection, installation UI, desktop progress, completed-game sync success/failure with controlled responses, and tap-to-move board interaction.
- A separate real browser fetch to Chess.com succeeded: archives HTTP 200, 26 archive months; latest month `2026/11` HTTP 200, 53 completed standard games. This verifies CORS access from the local app at test time, not permanent API availability.
- TypeScript and production build pass; dependency audit reports 0 known vulnerabilities at installation time.

**Not verified:** physical iPhone/Safari installation and runtime, hosted Cloudflare deployment, or background operation while iOS closes the app. Browser tests emulate the viewport and input; they are not physical iPhone tests.

## Reproduce historical analysis

```sh
npm run validate:pgn
npm run analyze:history
node --import tsx scripts/report-history.ts
```

Analysis resumes existing completed records in `public/data/analysis.json`. For a fresh engine run, move that file aside first. `scripts/refresh-lessons.ts` reapplies deterministic labels to existing engine evidence without rerunning Stockfish. When updating a shipped seed, increment the seed version in `src/lib/db.ts` so existing installations merge the new evidence while retaining reviews.

## Cloudflare Pages — prepared, not deployed

Use Cloudflare Pages' **Free** plan and the included `pages.dev` address. No custom domain purchase, Worker, Pages Function, KV, D1, or paid integration is needed. Build command: `npm run build`; output directory: `dist`; Node: 24. Alternatively, build locally and directly upload `dist`. No deployment command runs automatically.

The build is approximately 10 MB total; the largest asset is the approximately 7 MB Stockfish WASM, below Pages' documented 25 MiB per-asset limit. See Cloudflare's [React guide](https://developers.cloudflare.com/pages/framework-guides/deploy-a-react-site/) and [free-plan limits](https://developers.cloudflare.com/pages/platform/limits/). After deployment, open the HTTPS address in iPhone Safari → Share → Add to Home Screen. Load once online and wait for Offline ready.

## Source layout

- `src/lib/pgn.ts`: validation, identity and rating cohorts.
- `src/lib/engine.ts`: browser UCI adapter, also reused by offline Node preprocessing.
- `src/lib/teaching.ts`: evidence, concept rules, lesson selection and repetition.
- `src/lib/db.ts`: IndexedDB, import, backup and seed migration.
- `src/lib/sync.ts`: completed Chess.com archive import.
- `src/components/LessonPlayer.tsx`: attempt/hint/explanation/replay flow.
- `src/App.tsx`: dashboard, daily practice, progress and library.
- `scripts/`: reproducible data processing, asset preparation and offline manifest.
- `docs/DEVELOPMENT_PLAN.md`: architecture and phased scope.

## Engine attribution

Stockfish.js 17.1.0 by Nathan Rugg and contributors, based on Stockfish, is distributed unmodified under GPLv3. The included `public/engine/COPYING.txt` and `SOURCE.txt` identify the license and exact [corresponding source revision](https://github.com/nmrugg/stockfish.js/tree/602fd7e1a571a2be71f242942db90483731f2a1f). The source link and license are also accessible from the app. The app is not affiliated with Chess.com. API behavior follows its [Published Data API guidance](https://support.chess.com/en/articles/9650547-what-is-the-pubapi-and-how-do-i-use-it).

## GitHub Pages phone access

Production hosting uses the public `frankrolewicz-jpg/next-move` repository. The app and bundled public Chess.com history are public; practice progress remains in each browser's IndexedDB. The repository holds `site.zip` (the tested static build), `source.zip` (reproducible source), and `.github/workflows/pages.yml`. Pages uses GitHub Actions to extract and publish only the static build. No paid API, backend, account for app users, or running computer is required.

To update: run `npm ci`, `npm test`, `npm run typecheck`, and `VITE_BASE_PATH=/next-move/ npm run build`. Start `VITE_BASE_PATH=/next-move/ npm run preview -- --port 5173`, then run `PLAYWRIGHT_BASE_URL=http://127.0.0.1:5173/next-move/ npm run test:e2e`. After those pass, run `python3 scripts/package-pages.py` and replace `site.zip` and `source.zip` in the hosting repository. The workflow publishes that exact build. The Stockfish engine assets are regenerated by `npm run prepare:assets` from the locked package.

On iPhone, open the site in Safari, tap Share, then Add to Home Screen. Wait for “Offline ready” once while connected. Progress on the development site does not automatically transfer to the published site; use the app's backup export/import if needed. Physical iPhone/Safari behavior still needs testing on the user's device.
