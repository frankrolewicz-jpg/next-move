import { readFileSync, writeFileSync, readdirSync, existsSync } from "node:fs";
import { spawn } from "node:child_process";
import { createInterface } from "node:readline";
import { Engine, type Transport } from "../src/lib/engine";
import { analyzeGame } from "../src/lib/teaching";
import type { Game, Lesson, AnalysisRecord } from "../src/lib/types";
const games: Game[] = JSON.parse(
  readFileSync("public/data/games.json", "utf8"),
);
const rapid = games.filter((g) => g.rapid);
const recent = rapid.slice(-150);
const older = rapid.slice(0, -150);
const baseline = Array.from(
  { length: 30 },
  (_, i) => older[Math.floor((i * (older.length - 1)) / 29)],
);
const selected = [...recent].reverse().concat(baseline);
const path = "public/data/analysis.json";
const saved = existsSync(path)
  ? JSON.parse(readFileSync(path, "utf8"))
  : { lessons: [], records: [] };
const lessons: Lesson[] = saved.lessons;
const records: AnalysisRecord[] = saved.records;
const filename = readdirSync("node_modules/stockfish/src").find(
  (s) => s.includes("lite-single") && s.endsWith(".js"),
)!;
const child = spawn(
  process.execPath,
  ["node_modules/stockfish/src/" + filename],
  { stdio: ["pipe", "pipe", "pipe"] },
);
const transport: Transport = {
  postMessage: (s) => {
    child.stdin.write(s + "\n");
  },
  terminate: () => {
    child.kill();
  },
  onmessage: null,
  onerror: null,
};
createInterface({ input: child.stdout }).on("line", (line) =>
  transport.onmessage?.({ data: line }),
);
child.on("error", (e) => transport.onerror?.(e));
child.stderr.on("data", (d) => console.error(String(d)));
const engine = new Engine(transport);
const start = Date.now();
function save() {
  writeFileSync(
    path,
    JSON.stringify({
      engine: "Stockfish 17.1 lite single",
      screenDepth: 8,
      verificationDepth: 12,
      recentGameIds: recent.map((g) => g.id),
      baselineGameIds: baseline.map((g) => g.id),
      generatedAt: new Date().toISOString(),
      lessons,
      records,
    }),
  );
}
try {
  for (const game of selected) {
    if (records.some((r) => r.id === game.id)) continue;
    const result = await analyzeGame(game, (fen, depth) =>
      engine.evaluate(fen, depth),
    );
    lessons.push(...result.lessons);
    records.push({
      id: game.id,
      positions: result.positions,
      lessons: result.lessons.length,
      completedAt: Date.now(),
    });
    save();
    console.log(
      `${records.length}/${selected.length} ${game.date.slice(0, 10)} ${result.positions} positions, ${result.lessons.length} lessons, ${Math.round((Date.now() - start) / 1000)}s`,
    );
  }
} finally {
  save();
  engine.close();
}
