"""Package the locally tested build and its reproducible source for browser upload."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib

root = Path(__file__).resolve().parent.parent
out = root / 'deployment'
out.mkdir(exist_ok=True)
assert '/next-move/assets/' in (root / 'dist/index.html').read_text(), 'Build with VITE_BASE_PATH=/next-move/'
with ZipFile(out / 'site.zip', 'w', ZIP_DEFLATED) as archive:
    for path in sorted((root / 'dist').rglob('*')):
        if path.is_file() and path.name != '_headers':
            archive.write(path, path.relative_to(root / 'dist'))
    archive.writestr('.nojekyll', '')
with ZipFile(out / 'source.zip', 'w', ZIP_DEFLATED) as archive:
    roots = ['src', 'scripts', 'tests', 'docs', '.github', 'public/data', 'public/icons']
    files = [p for folder in roots for p in (root / folder).rglob('*') if p.is_file()]
    files += [root / name for name in ['package.json', 'package-lock.json', 'tsconfig.json', 'vite.config.ts', 'vitest.config.ts', 'playwright.config.ts', 'index.html', 'README.md', '.node-version', '.gitignore', 'public/manifest.webmanifest', 'public/_headers', 'data/all_chess_games.pgn', 'data/rating-history.csv', 'data/validation-report.json']]
    for path in sorted(files):
        archive.write(path, path.relative_to(root))
for name in ['site.zip', 'source.zip']:
    path = out / name
    with ZipFile(path) as archive:
        assert archive.testzip() is None
    print(name, path.stat().st_size, 'bytes, sha256', hashlib.sha256(path.read_bytes()).hexdigest())
