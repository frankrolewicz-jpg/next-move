import { chromium } from "@playwright/test";
const browser = await chromium.launch({
  executablePath:
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
});
try {
  const page = await browser.newPage();
  await page.goto("http://127.0.0.1:5173");
  const result = await page.evaluate(async () => {
    try {
      const r = await fetch(
        "https://api.chess.com/pub/player/frankrolewicz/games/archives",
        { signal: AbortSignal.timeout(15000) },
      );
      const body = await r.json();
      if (!r.ok) return { status: r.status };
      const latest = body.archives?.at(-1);
      if (!latest) return { status: r.status, archives: 0 };
      const month = await fetch(latest, { signal: AbortSignal.timeout(15000) });
      const games = await month.json();
      return {
        status: r.status,
        archives: body.archives.length,
        latestMonth: latest.slice(-7),
        monthStatus: month.status,
        completedGames: games.games?.filter(
          (g) => g.end_time && g.pgn && g.rules === "chess",
        ).length,
      };
    } catch (e) {
      return { error: String(e) };
    }
  });
  console.log(JSON.stringify(result, null, 2));
} finally {
  await browser.close();
}
