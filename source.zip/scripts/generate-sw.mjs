import { readdirSync, readFileSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";
function walk(path) {
  return readdirSync(path, { withFileTypes: true }).flatMap((e) =>
    e.isDirectory() ? walk(path + "/" + e.name) : [path + "/" + e.name],
  );
}
const files = walk("dist").filter(
  (f) => !f.endsWith("/sw.js") && !f.endsWith("/_headers"),
);
const version = createHash("sha256");
for (const f of files) version.update(readFileSync(f));
writeFileSync(
  "dist/sw.js",
  `const PREFIX='next-move-'+new URL(self.registration.scope).pathname+'-';
const CACHE=PREFIX+'${version.digest("hex").slice(0, 12)}';
const ASSETS=${JSON.stringify(files.map((f) => f.replace(/^dist\//, "")))}.map(path=>new URL(path,self.registration.scope).href);
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS))));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith(PREFIX)&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{const url=new URL(event.request.url);if(event.request.method!=='GET'||url.origin!==self.location.origin)return;event.respondWith(caches.open(CACHE).then(cache=>cache.match(event.request.mode==='navigate'?new URL('index.html',self.registration.scope).href:event.request,{ignoreVary:true}).then(cached=>cached||fetch(event.request))));});
`,
);
console.log("Offline cache generated:", files.length, "assets");
