import { readFileSync, writeFileSync } from "node:fs";
import type { Game, Lesson, AnalysisRecord } from "../src/lib/types";
const profile = JSON.parse(readFileSync("data/validation-report.json", "utf8"));
const games: Game[] = JSON.parse(
  readFileSync("public/data/games.json", "utf8"),
);
const analysis: {
  lessons: Lesson[];
  records: AnalysisRecord[];
  recentGameIds: string[];
  baselineGameIds: string[];
} = JSON.parse(readFileSync("public/data/analysis.json", "utf8"));
const recent = new Set(analysis.recentGameIds);
const baseline = new Set(analysis.baselineGameIds);
const rows = [...new Set(analysis.lessons.map((l) => l.theme))]
  .map((theme) => {
    const a = analysis.lessons.filter(
      (l) => l.theme === theme && recent.has(l.gameId),
    );
    const b = analysis.lessons.filter(
      (l) => l.theme === theme && baseline.has(l.gameId),
    );
    return {
      theme,
      recent: a.length,
      recentGames: new Set(a.map((l) => l.gameId)).size,
      older: b.length,
      olderGames: new Set(b.map((l) => l.gameId)).size,
    };
  })
  .sort((a, b) => b.recent - a.recent);
const years = [...new Set(games.map((g) => g.date.slice(0, 4)))].map((year) => {
  const a = games.filter((g) => g.date.startsWith(year));
  return `| ${year} | ${a.length} | ${Math.round(a.reduce((s, g) => s + g.rating, 0) / a.length)} | ${Math.min(...a.map((g) => g.rating))}–${Math.max(...a.map((g) => g.rating))} |`;
});
const examples = rows.slice(0, 6).map((row) => {
  const l = analysis.lessons
    .filter((l) => l.theme === row.theme && recent.has(l.gameId))
    .sort((a, b) => Math.abs(a.before.cp) - Math.abs(b.before.cp))[0];
  return `### ${row.theme}\n\n${l.date.slice(0, 10)}, against ${l.opponent}, playing ${l.color === "w" ? "White" : "Black"}, move ${Math.floor(l.ply / 2) + 1}.\n\n${l.explanation}\n\n- Preferred line: ${l.line.join(" ")}\n- After ${l.playedSan}: ${l.punishment.join(" ")}\n- Position: \`${l.fen}\`\n- Evidence ID: \`${l.id}\`\n`;
});
const report = `# Frankrolewicz — historical assessment\n\n## Validated source\n\nThe supplied file was \`data/all_chess_games.rtf\`, not PGN. The original is preserved; macOS textutil extracted plain text into \`data/all_chess_games.pgn\`. chess.js replayed every move. ${profile.records} records produced ${profile.uniqueGames} unique completed standard rapid games, with ${profile.duplicates} duplicates and ${profile.errors.length} errors. Every game includes Frankrolewicz.\n\nDate range: February 19, 2022–November 10, 2026. Header ratings: first ${profile.firstRating}, latest ${profile.currentRating}, peak ${profile.peakRating}. These are recorded ratings at game time, not a current account lookup or guaranteed post-game ratings. Games without UTC start times are ordered using EndTime; same-day ordering may be imperfect around midnight.\n\n## Performance changes\n\n| Cohort | Average rating | Wins | Losses | Draws | Score rate |\n|---|---:|---:|---:|---:|---:|\n| Previous 150 rapid games | ${profile.prior.averageRating} | ${profile.prior.wins} | ${profile.prior.losses} | ${profile.prior.draws} | ${profile.prior.score}% |\n| Latest 150 rapid games | ${profile.recent.averageRating} | ${profile.recent.wins} | ${profile.recent.losses} | ${profile.recent.draws} | ${profile.recent.score}% |\n\nYour recent playing level averages 56 points higher, but your score rate has not improved. This suggests a higher rating baseline with continued inconsistency; it does not establish a cause. The full history is not a steady upward trajectory: the 964 peak occurred on November 20, 2024, followed by a low of 482 on January 23, 2026. The recent 789 average indicates recovery from that low but remains below the earlier peak. Gaps in play and the small 2024 sample make year-to-year comparisons imperfect.\n\n| Year | Games | Average rating | Rating range |\n|---|---:|---:|---:|\n${years.join("\n")}\n\n## Verified lesson evidence\n\nStockfish 17.1 lite single-threaded screened ${analysis.records.reduce((s, r) => s + r.positions, 0)} player decisions in all 150 recent rapid games and 30 evenly spaced older games. Terminal positions were skipped. Screening depth: 8; verification depth: 12. Up to three high-loss candidates per game were rechecked. Each retained lesson loses at least 1.4 pawn-equivalents relative to best play; positions already worse than -4.0 were excluded. Mate scores use a separate large ordering value, not a literal pawn count.\n\n${analysis.lessons.length} lessons survived verification: ${analysis.lessons.filter((l) => recent.has(l.gameId)).length} recent and ${analysis.lessons.filter((l) => baseline.has(l.gameId)).length} older. All source positions and full stored principal variations are legally replayed by tests. Finite-depth search is not proof of a unique best move.\n\n| Theme | Recent lessons | Recent games / 150 | Older sample lessons | Older sample games / 30 |\n|---|---:|---:|---:|---:|\n${rows.map((r) => `| ${r.theme} | ${r.recent} | ${r.recentGames} | ${r.older} | ${r.olderGames} |`).join("\n")}\n\nThese counts describe a capped selection of teaching positions, not all blunders or their true frequency. The older sample is small and covers several years; do not interpret raw counts as a statistically controlled improvement measurement. The app uses all historical ratings for the reliable performance comparison and weights only the latest 150 games for current lesson priorities.\n\n## Teaching priorities\n\n1. Before committing a move, name your opponent's strongest check or capture. Verified material-loss examples require a net material deficit in the displayed continuation; an equal exchange is not labeled a material-loss tactic.\n2. Compare at least two candidates, calculate a forcing reply, and check the resulting position again. “Calculation” is a general decision label, not an invented fork/pin diagnosis.\n3. Search checks and captures before quiet moves, including mating continuations.\n4. In selected strategic lessons, develop a minor piece from its starting square or use a pawn-free file with a rook only when those facts are present and Stockfish prefers the move. Other opening/endgame labels describe phase only.\n\n## Examples from actual games\n\n${examples.join("\n")}\n## Daily practice\n\nSpend about three minutes recalling due positions, twelve minutes attempting recent weaknesses, and five minutes explaining the threat and replaying alternatives. Try before revealing. Hints reduce the review grade; failed or revealed cards return in ten minutes. Successful reviews begin at one day, grow to a maximum of thirty days, and require three spaced successes for mastery. Early manual revisits do not earn additional mastery. Priority rises with recent-game frequency and practice lapses.\n\nThis is a training plan toward 1400, not a predicted or guaranteed rating gain.\n`;
writeFileSync("docs/HISTORY_REPORT.md", report);
console.log("Wrote docs/HISTORY_REPORT.md");
