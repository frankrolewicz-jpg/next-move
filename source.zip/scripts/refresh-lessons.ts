import { readFileSync, writeFileSync } from "node:fs";
import { makeLesson } from "../src/lib/teaching";
import type { Game, Lesson } from "../src/lib/types";
const games: Game[] = JSON.parse(
  readFileSync("public/data/games.json", "utf8"),
);
const map = new Map(games.map((g) => [g.id, g]));
const data = JSON.parse(readFileSync("public/data/analysis.json", "utf8"));
data.lessons = data.lessons
  .map((l: Lesson) =>
    makeLesson(map.get(l.gameId)!, l.fen, l.ply, l.played, l.before, l.after),
  )
  .filter(Boolean);
writeFileSync("public/data/analysis.json", JSON.stringify(data));
console.log(
  "Reclassified",
  data.lessons.length,
  "lessons using existing engine evidence.",
);
