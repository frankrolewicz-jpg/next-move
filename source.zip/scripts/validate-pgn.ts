import { readFileSync, writeFileSync } from "node:fs";
import { parseGames, summarize } from "../src/lib/pgn";
const raw = readFileSync("data/all_chess_games.pgn", "utf8");
const result = parseGames(raw);
const report = {
  source:
    "data/all_chess_games.rtf converted losslessly to plain PGN using macOS textutil",
  username: result.username,
  records: result.records,
  uniqueGames: result.games.length,
  duplicates: result.duplicates,
  errors: result.errors,
  ...summarize(result.games),
};
writeFileSync("data/validation-report.json", JSON.stringify(report, null, 2));
writeFileSync(
  "data/rating-history.csv",
  "date,rating,game_id\n" +
    report.ratingHistory
      .map((g) => `${g.date},${g.rating},${g.id}`)
      .join("\n") +
    "\n",
);
writeFileSync("public/data/games.json", JSON.stringify(result.games));
writeFileSync("public/data/profile.json", JSON.stringify(report));
console.log(
  JSON.stringify(
    {
      ...report,
      ratingHistory: `${report.ratingHistory.length} rows exported to data/rating-history.csv`,
    },
    null,
    2,
  ),
);
if (result.errors.length) process.exitCode = 1;
