import { mkdirSync, copyFileSync, readdirSync, writeFileSync } from "node:fs";
mkdirSync("public/engine", { recursive: true });
const engine = readdirSync("node_modules/stockfish/src").find(
  (s) => s.includes("lite-single") && s.endsWith(".js"),
);
copyFileSync(
  "node_modules/stockfish/src/" + engine,
  "public/engine/stockfish.js",
);
// Loader resolves the WASM alongside its own URL under the same basename.
copyFileSync(
  "node_modules/stockfish/src/" + engine.replace(".js", ".wasm"),
  "public/engine/stockfish.wasm",
);
copyFileSync("node_modules/stockfish/Copying.txt", "public/engine/COPYING.txt");
writeFileSync(
  "public/engine/SOURCE.txt",
  "Stockfish.js 17.1.0 lite single-threaded, distributed unmodified under GPLv3.\nCorresponding source and build instructions: https://github.com/nmrugg/stockfish.js/tree/602fd7e1a571a2be71f242942db90483731f2a1f\nUpstream chess engine: https://github.com/official-stockfish/Stockfish/tree/sf_17.1\nPackage: https://registry.npmjs.org/stockfish/-/stockfish-17.1.0.tgz\n",
);
