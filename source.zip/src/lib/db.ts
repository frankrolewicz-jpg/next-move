import { openDB, type DBSchema } from "idb";
import { parseGames } from "./pgn";
import type { Game, Lesson, Review, Session, AnalysisRecord } from "./types";
interface CoachDB extends DBSchema {
  games: { key: string; value: Game };
  lessons: { key: string; value: Lesson };
  reviews: { key: string; value: Review };
  sessions: { key: string; value: Session };
  analysis: { key: string; value: AnalysisRecord };
  settings: { key: string; value: unknown };
}
let connection: ReturnType<typeof openDB<CoachDB>> | undefined;
export function db() {
  return (connection ??= openDB<CoachDB>("chess-coach", 1, {
    upgrade(d) {
      for (const name of ["games", "lessons", "reviews", "analysis"] as const)
        d.createObjectStore(name, { keyPath: "id" });
      d.createObjectStore("sessions", { keyPath: "day" });
      d.createObjectStore("settings");
    },
  }));
}
async function getJson(url: string) {
  const r = await fetch(import.meta.env.BASE_URL + url.replace(/^\//, ""));
  if (!r.ok)
    throw Error("Could not load your history. Please reconnect and retry.");
  return r.json();
}
export async function bootstrap() {
  const d = await db();
  if ((await d.get("settings", "initialized")) === "seed-2026-11-10-v2") return;
  const [games, analysis] = await Promise.all([
    getJson("/data/games.json"),
    getJson("/data/analysis.json"),
  ]);
  const oldLessons = await d.getAll("lessons");
  const seedGames = new Set<string>(games.map((g: Game) => g.id));
  const seedLessons = new Set<string>(
    analysis.lessons.map((l: Lesson) => l.id),
  );
  const tx = d.transaction(
    ["games", "lessons", "analysis", "settings"],
    "readwrite",
  );
  for (const l of oldLessons)
    if (seedGames.has(l.gameId) && !seedLessons.has(l.id))
      await tx.objectStore("lessons").delete(l.id);
  for (const g of games) await tx.objectStore("games").put(g);
  for (const l of analysis.lessons) await tx.objectStore("lessons").put(l);
  for (const r of analysis.records) await tx.objectStore("analysis").put(r);
  await tx.objectStore("settings").put("Frankrolewicz", "username");
  await tx.objectStore("settings").put("seed-2026-11-10-v2", "initialized");
  await tx.done;
}
export async function snapshot() {
  const d = await db();
  const [games, lessons, reviews, sessions, analysis] = await Promise.all([
    d.getAll("games"),
    d.getAll("lessons"),
    d.getAll("reviews"),
    d.getAll("sessions"),
    d.getAll("analysis"),
  ]);
  games.sort(
    (a, b) => a.date.localeCompare(b.date) || a.id.localeCompare(b.id),
  );
  return { games, lessons, reviews, sessions, analysis };
}
function signature(g: Game) {
  return [
    g.headers.White.toLowerCase(),
    g.headers.Black.toLowerCase(),
    g.date.slice(0, 10),
    g.headers.TimeControl,
    g.headers.Result,
    g.headers.FEN || "",
    g.moves.join(" "),
  ].join("|");
}
export async function importPgn(text: string) {
  const d = await db();
  const username = String(
    (await d.get("settings", "username")) || "Frankrolewicz",
  );
  const parsed = parseGames(text, username);
  const existing = await d.getAll("games");
  const signatures = new Set(existing.map(signature));
  let added = 0;
  const tx = d.transaction("games", "readwrite");
  for (const g of parsed.games) {
    const key = signature(g);
    if (!signatures.has(key)) {
      await tx.store.put(g);
      signatures.add(key);
      added++;
    }
  }
  await tx.done;
  return {
    added,
    rejected: parsed.errors.length,
    duplicates: parsed.duplicates + parsed.games.length - added,
    errors: parsed.errors,
  };
}
export async function saveAnalysis(
  game: Game,
  lessons: Lesson[],
  positions: number,
) {
  const d = await db();
  const tx = d.transaction(["lessons", "analysis"], "readwrite");
  for (const l of lessons) await tx.objectStore("lessons").put(l);
  await tx.objectStore("analysis").put({
    id: game.id,
    positions,
    lessons: lessons.length,
    completedAt: Date.now(),
  });
  await tx.done;
}
export function dayKey(date = new Date()) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
export async function recordAttempt(review: Review, correct: boolean) {
  const d = await db();
  const tx = d.transaction(["reviews", "sessions"], "readwrite");
  await tx.objectStore("reviews").put(review);
  const day = dayKey();
  const session = (await tx.objectStore("sessions").get(day)) || {
    day,
    seconds: 0,
    attempts: 0,
    correct: 0,
  };
  session.attempts++;
  if (correct) session.correct++;
  await tx.objectStore("sessions").put(session);
  await tx.done;
}
export async function addTime(seconds: number) {
  const d = await db();
  const day = dayKey();
  const tx = d.transaction("sessions", "readwrite");
  const session = (await tx.store.get(day)) || {
    day,
    seconds: 0,
    attempts: 0,
    correct: 0,
  };
  session.seconds += seconds;
  await tx.store.put(session);
  await tx.done;
}
export async function exportBackup() {
  return JSON.stringify(
    { version: 1, exportedAt: new Date().toISOString(), ...(await snapshot()) },
    null,
    2,
  );
}
export async function restoreBackup(text: string) {
  const data = JSON.parse(text);
  if (
    data.version !== 1 ||
    !Array.isArray(data.games) ||
    !Array.isArray(data.reviews) ||
    !Array.isArray(data.sessions)
  )
    throw Error("Unsupported backup file");
  // Games are revalidated; lesson evidence is regenerated locally instead of trusting imported evaluations.
  const result = await importPgn(
    data.games.map((g: { pgn: string }) => g.pgn).join("\n\n"),
  );
  const d = await db();
  const tx = d.transaction(["reviews", "sessions"], "readwrite");
  for (const r of data.reviews) {
    if (
      typeof r.id !== "string" ||
      ![
        "due",
        "interval",
        "successes",
        "attempts",
        "lapses",
        "lastQuality",
      ].every((k) => Number.isFinite(r[k]) && r[k] >= 0)
    )
      continue;
    await tx.objectStore("reviews").put(r);
  }
  for (const s of data.sessions) {
    if (
      !/^\d{4}-\d{2}-\d{2}$/.test(s.day) ||
      !["seconds", "attempts", "correct"].every(
        (k) => Number.isFinite(s[k]) && s[k] >= 0,
      )
    )
      continue;
    await tx.objectStore("sessions").put(s);
  }
  await tx.done;
  return result;
}
