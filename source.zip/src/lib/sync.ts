import { db, importPgn } from "./db";
export async function syncChessCom(
  onProgress: (s: string) => void,
  force = false,
) {
  const d = await db();
  const last = Number((await d.get("settings", "lastSync")) || 0);
  if (!force && Date.now() - last < 6 * 3600000)
    return "Already checked within the last 6 hours.";
  const username = String(
    (await d.get("settings", "username")) || "Frankrolewicz",
  );
  async function get(url: string) {
    const r = await fetch(url, { signal: AbortSignal.timeout(20000) });
    if (!r.ok)
      throw Error(
        r.status === 429
          ? "Chess.com rate limit reached. Try again later."
          : `Chess.com returned ${r.status}. You can import a PGN instead.`,
      );
    return r.json();
  }
  const data = await get(
    `https://api.chess.com/pub/player/${encodeURIComponent(username.toLowerCase())}/games/archives`,
  );
  if (!Array.isArray(data.archives))
    throw Error("Unexpected Chess.com archive response");
  // First sync reconciles the latest two months. Later syncs catch every month since last success.
  const cutoff = new Date(last || Date.now());
  cutoff.setUTCMonth(cutoff.getUTCMonth() - 1);
  const month = `${cutoff.getUTCFullYear()}/${String(cutoff.getUTCMonth() + 1).padStart(2, "0")}`;
  const prefix = `https://api.chess.com/pub/player/${username.toLowerCase()}/games/`;
  const urls = data.archives.filter(
    (u: unknown): u is string =>
      typeof u === "string" &&
      u.startsWith(prefix) &&
      /^\d{4}\/\d{2}$/.test(u.slice(prefix.length)) &&
      u.slice(-7) >= month,
  );
  let count = 0;
  for (const url of urls) {
    onProgress("Checking completed games · " + url.slice(-7));
    const archive = await get(url);
    if (!Array.isArray(archive.games))
      throw Error("Unexpected Chess.com games response");
    const pgn = archive.games
      .filter(
        (g: { rules?: string; end_time?: number; pgn?: string }) =>
          g.rules === "chess" &&
          g.end_time &&
          g.end_time * 1000 <= Date.now() &&
          g.pgn,
      )
      .map((g: { pgn: string }) => g.pgn)
      .join("\n\n");
    if (pgn) {
      const imported = await importPgn(pgn);
      if (imported.rejected)
        throw Error(
          `${imported.rejected} games could not be validated. ${count + imported.added} games imported; sync will retry later.`,
        );
      count += imported.added;
    }
  }
  await d.put("settings", Date.now(), "lastSync");
  return `${count} new completed games imported.`;
}
