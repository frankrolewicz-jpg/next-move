export type Game = {
  id: string;
  pgn: string;
  headers: Record<string, string>;
  moves: string[];
  date: string;
  color: "w" | "b";
  rating: number;
  opponent: string;
  result: "win" | "loss" | "draw";
  rapid: boolean;
};
export type Evaluation = {
  cp: number;
  mate?: number;
  depth: number;
  pv: string[];
  best: string;
};
export type Lesson = {
  id: string;
  gameId: string;
  date: string;
  opponent: string;
  color: "w" | "b";
  fen: string;
  ply: number;
  played: string;
  playedSan: string;
  best: string;
  bestSan: string;
  loss: number;
  before: Evaluation;
  after: Evaluation;
  theme: string;
  explanation: string;
  line: string[];
  punishment: string[];
  hints: string[];
};
export type Review = {
  id: string;
  due: number;
  interval: number;
  successes: number;
  attempts: number;
  lapses: number;
  lastQuality: number;
};
export type Session = {
  day: string;
  seconds: number;
  attempts: number;
  correct: number;
};
export type AnalysisRecord = {
  id: string;
  positions: number;
  lessons: number;
  completedAt: number;
};
