import { Chess, type Square } from "chess.js";
import type { Evaluation, Game, Lesson, Review } from "./types";
export const pieceNames: Record<string, string> = {
  p: "pawn",
  n: "knight",
  b: "bishop",
  r: "rook",
  q: "queen",
  k: "king",
};
export function playUci(chess: Chess, uci: string) {
  return chess.move({
    from: uci.slice(0, 2),
    to: uci.slice(2, 4),
    promotion: uci[4],
  });
}
export function legalLine(fen: string, pv: string[], limit = 6) {
  const chess = new Chess(fen);
  const result: string[] = [];
  for (const uci of pv.slice(0, limit)) {
    try {
      result.push(playUci(chess, uci).san);
    } catch {
      break;
    }
  }
  return result;
}
export function scoreText(e: Evaluation, flip = false) {
  if (e.mate !== undefined) {
    const m = flip ? -e.mate : e.mate;
    return m > 0
      ? `a forced mate in ${Math.abs(m)}`
      : `being mated in ${Math.abs(m)}`;
  }
  return `${((flip ? -e.cp : e.cp) / 100).toFixed(2)} pawns`;
}
function material(fen: string, color: "w" | "b") {
  return new Chess(fen)
    .board()
    .flat()
    .reduce(
      (sum, p) =>
        sum +
        (p
          ? { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 }[p.type] *
            (p.color === color ? 1 : -1)
          : 0),
      0,
    );
}
function materialAfter(fen: string, pv: string[], color: "w" | "b") {
  const c = new Chess(fen);
  for (const uci of pv.slice(0, 6)) {
    try {
      playUci(c, uci);
    } catch {
      break;
    }
  }
  return material(c.fen(), color);
}
export function makeLesson(
  game: Game,
  fen: string,
  ply: number,
  played: string,
  before: Evaluation,
  after: Evaluation,
): Lesson | null {
  const loss = Math.max(0, before.cp + after.cp);
  if (
    before.cp < -400 ||
    loss < 140 ||
    before.best === played ||
    before.depth < 12 ||
    after.depth < 12
  )
    return null;
  const chess = new Chess(fen);
  const bestMove = playUci(chess, before.best);
  const line = legalLine(fen, before.pv);
  if (!line.length) return null;
  const actual = new Chess(fen);
  const actualMove = playUci(actual, played);
  const punishment = legalLine(actual.fen(), after.pv);
  if (!punishment.length) return null;
  const reply = new Chess(actual.fen());
  const replyMove = playUci(reply, after.best);
  const pieces = new Chess(fen).board().flat().filter(Boolean).length;
  const materialLoss =
    materialAfter(actual.fen(), after.pv, game.color) -
    material(fen, game.color);
  const bestMaterial =
    materialAfter(fen, before.pv, game.color) - material(fen, game.color);
  const develops =
    ply < 20 &&
    ["n", "b"].includes(bestMove.piece) &&
    ["b1", "g1", "c1", "f1", "b8", "g8", "c8", "f8"].includes(bestMove.from) &&
    !bestMove.captured;
  const openFile =
    bestMove.piece === "r" &&
    bestMove.from[0] !== bestMove.to[0] &&
    !chess
      .board()
      .flat()
      .some((p) => p?.type === "p" && p.square[0] === bestMove.to[0]);
  const theme =
    before.mate !== undefined &&
    before.mate > 0 &&
    !(after.mate !== undefined && after.mate < 0)
      ? "Missed mate"
      : after.mate !== undefined &&
          after.mate > 0 &&
          !(before.mate !== undefined && before.mate < 0)
        ? "King safety"
        : replyMove.captured &&
            materialLoss <= -2 &&
            materialLoss < bestMaterial - 1
          ? "Material under threat"
          : bestMove.captured
            ? "Missed capture"
            : develops
              ? "Piece development"
              : openFile
                ? "Open-file rook activity"
                : pieces <= 12
                  ? "Endgame decisions"
                  : ply < 20
                    ? "Opening decisions"
                    : "Calculation";
  const fact =
    theme === "Piece development"
      ? `${bestMove.san} develops your ${pieceNames[bestMove.piece]} from its starting square ${bestMove.from}.`
      : theme === "Open-file rook activity"
        ? `${bestMove.san} places your rook on the ${bestMove.to[0]}-file, which has no pawns from either side in this position.`
        : theme === "Material under threat"
          ? `The engine's reply ${replyMove.san} captures your ${pieceNames[replyMove.captured!]}. In the displayed continuation your material balance falls by ${Math.abs(materialLoss)} points (pawn 1, minor piece 3, rook 5, queen 9).`
          : bestMove.captured
            ? `${bestMove.san} captures a ${pieceNames[bestMove.captured]}.`
            : bestMove.san.includes("+")
              ? `${bestMove.san} gives check.`
              : bestMove.san.includes("#")
                ? `${bestMove.san} is checkmate.`
                : `Compare your opponent's strongest reply to each candidate.`;
  return {
    id: game.id + "-" + ply,
    gameId: game.id,
    date: game.date,
    opponent: game.opponent,
    color: game.color,
    fen,
    ply,
    played,
    playedSan: actualMove.san,
    best: before.best,
    bestSan: bestMove.san,
    loss,
    before,
    after,
    theme,
    line,
    punishment,
    explanation: `You played ${actualMove.san}. Stockfish prefers ${bestMove.san}. ${fact} From your side, the evaluation changes from ${scoreText(before)} to ${scoreText(after, true)} after your move. The lines below show the engine's best replies at depth ${Math.min(before.depth, after.depth)}; they are continuations, not a prediction of what your opponent played.`,
    hints: [
      new Chess(fen).isCheck()
        ? "Your king is in check. Compare legal ways to escape."
        : theme === "King safety"
          ? "Check your opponent’s forcing threats against your king."
          : theme === "Missed mate"
            ? "Look for a forcing sequence against the enemy king."
            : "Start with checks, captures, and your opponent’s threats.",
      `Look closely at your ${pieceNames[bestMove.piece]} on ${bestMove.from}.`,
      `Find a safe route to ${bestMove.to}.`,
    ],
  };
}
export async function analyzeGame(
  game: Game,
  evaluate: (fen: string, depth: number) => Promise<Evaluation>,
  onProgress?: (n: number) => void,
) {
  const chess = new Chess();
  chess.loadPgn(game.pgn);
  const history = chess.history({ verbose: true });
  const candidates: {
    fen: string;
    ply: number;
    played: string;
    loss: number;
  }[] = [];
  let positions = 0;
  for (let i = 0; i < history.length; i++) {
    const move = history[i];
    if (move.color !== game.color) continue;
    const afterBoard = new Chess(move.after);
    if (afterBoard.isGameOver()) continue;
    const before = await evaluate(move.before, 8);
    const after = await evaluate(move.after, 8);
    positions++;
    const loss = before.cp + after.cp;
    if (before.cp >= -400 && loss >= 120 && before.best !== move.lan)
      candidates.push({ fen: move.before, ply: i, played: move.lan, loss });
    onProgress?.(positions);
  }
  const lessons: Lesson[] = [];
  for (const c of candidates.sort((a, b) => b.loss - a.loss).slice(0, 3)) {
    const before = await evaluate(c.fen, 12);
    const actual = new Chess(c.fen);
    playUci(actual, c.played);
    const after = await evaluate(actual.fen(), 12);
    const lesson = makeLesson(game, c.fen, c.ply, c.played, before, after);
    if (lesson) lessons.push(lesson);
  }
  return { lessons, positions };
}
export function scheduleReview(
  old: Review | undefined,
  id: string,
  quality: number,
  now = Date.now(),
): Review {
  if (old && old.due > now && quality >= 3)
    return { ...old, attempts: old.attempts + 1 };
  const success = quality >= 3;
  const interval = success
    ? old?.successes
      ? Math.min(30, Math.max(1, old.interval) * (quality === 5 ? 2.5 : 1.5))
      : 1
    : 0;
  return {
    id,
    due: now + (success ? interval * 86400000 : 10 * 60000),
    interval,
    successes: success ? (old?.successes || 0) + 1 : 0,
    attempts: (old?.attempts || 0) + 1,
    lapses: (old?.lapses || 0) + (success ? 0 : 1),
    lastQuality: quality,
  };
}
export function chooseLessons(
  lessons: Lesson[],
  reviews: Review[],
  games: Game[],
  now = Date.now(),
) {
  const recent = new Set(
    games
      .filter((g) => g.rapid)
      .slice(-150)
      .map((g) => g.id),
  );
  const map = new Map(reviews.map((r) => [r.id, r]));
  const weakness = new Map<string, number>();
  for (const l of lessons)
    if (recent.has(l.gameId))
      weakness.set(
        l.theme,
        (weakness.get(l.theme) || 0) + 1 + (map.get(l.id)?.lapses || 0),
      );
  return lessons
    .filter((l) => !map.has(l.id) || map.get(l.id)!.due <= now)
    .sort((a, b) => {
      const score = (l: Lesson) => {
        const r = map.get(l.id);
        return (
          (r ? 1000 : 0) +
          (recent.has(l.gameId) ? 100 : 0) +
          (weakness.get(l.theme) || 0) +
          (r?.lapses || 0) * 20
        );
      };
      return score(b) - score(a) || b.date.localeCompare(a.date);
    });
}
export function uciFromSquares(from: string, to: string, promotion = "q") {
  return from + to + (to[1] === "1" || to[1] === "8" ? promotion : "");
}
export function pieceAt(fen: string, square: string) {
  return new Chess(fen).get(square as Square);
}
