import type { Evaluation } from "./types";
export interface Transport {
  postMessage: (s: string) => void;
  terminate: () => void;
  onmessage: ((event: { data: string }) => void) | null;
  onerror: ((event: unknown) => void) | null;
}
export function parseInfo(line: string): Evaluation | null {
  const score = line.match(/score (cp|mate) (-?\d+)/),
    depth = line.match(/depth (\d+)/),
    pv = line.match(/\bpv (.+)$/);
  if (!score || !depth || !pv || /\b(upperbound|lowerbound)\b/.test(line))
    return null;
  const n = Number(score[2]);
  return {
    cp:
      score[1] === "cp" ? n : Math.sign(n || -1) * (100000 - Math.abs(n) * 100),
    mate: score[1] === "mate" ? n : undefined,
    depth: +depth[1],
    pv: pv[1].split(" "),
    best: pv[1].split(" ")[0],
  };
}
export class Engine {
  private transport: Transport;
  private pending?: {
    resolve: (s: string) => void;
    reject: (e: Error) => void;
    match: (s: string) => boolean;
    timer: ReturnType<typeof setTimeout>;
  };
  private latest: Evaluation | null = null;
  private chain: Promise<unknown> = Promise.resolve();
  private ready: Promise<void>;
  private closed = false;
  constructor(transport?: Transport) {
    this.transport =
      transport ||
      (new Worker(
        import.meta.env.BASE_URL + "engine/stockfish.js",
      ) as unknown as Transport);
    this.transport.onmessage = (e) => {
      for (const line of String(e.data).split("\n")) {
        const info = parseInfo(line);
        if (info) this.latest = info;
        if (this.pending?.match(line)) {
          const p = this.pending;
          this.pending = undefined;
          clearTimeout(p.timer);
          p.resolve(line);
        }
      }
    };
    this.transport.onerror = () =>
      this.fail(
        Error(
          "Stockfish could not load. Reconnect once to download the offline engine.",
        ),
      );
    this.ready = this.initialize();
    this.ready.catch(() => {});
  }
  private fail(e: Error) {
    this.closed = true;
    this.transport.terminate();
    if (this.pending) {
      clearTimeout(this.pending.timer);
      this.pending.reject(e);
      this.pending = undefined;
    }
  }
  private wait(command: string, match: (s: string) => boolean, ms = 60000) {
    return new Promise<string>((resolve, reject) => {
      if (this.closed) {
        reject(Error("Analysis stopped"));
        return;
      }
      this.pending = {
        resolve,
        reject,
        match,
        timer: setTimeout(
          () => this.fail(Error("Engine timed out. Please retry.")),
          ms,
        ),
      };
      this.transport.postMessage(command);
    });
  }
  private async initialize() {
    await this.wait("uci", (s) => s === "uciok");
    this.transport.postMessage("setoption name Hash value 16");
    await this.wait("isready", (s) => s === "readyok");
  }
  evaluate(fen: string, depth = 12): Promise<Evaluation> {
    const job = this.chain.then(async () => {
      await this.ready;
      if (this.closed) throw Error("Analysis stopped");
      this.latest = null;
      this.transport.postMessage("position fen " + fen);
      const line = await this.wait("go depth " + depth, (s) =>
        s.startsWith("bestmove "),
      );
      const best = line.split(" ")[1];
      if (!this.latest || !best || best === "(none)")
        throw Error("No legal engine continuation");
      return { ...(this.latest as Evaluation), best };
    });
    this.chain = job.catch(() => {});
    return job;
  }
  close() {
    this.fail(Error("Analysis stopped"));
  }
}
