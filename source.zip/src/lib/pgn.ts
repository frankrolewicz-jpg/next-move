import { Chess } from "chess.js";
import type { Game } from "./types";
export function splitPgn(text: string) {
  return text
    .replace(/^\uFEFF/, "")
    .split(/(?=^\[Event\s)/m)
    .map((s) => s.trim())
    .filter(Boolean);
}
export function hash(s: string) {
  let h = 2166136261;
  for (const c of s) h = Math.imul(h ^ c.charCodeAt(0), 16777619);
  return (h >>> 0).toString(16);
}
export function parseGames(text: string, username?: string) {
  const chunks = splitPgn(text);
  const players = new Map<string, number>();
  for (const chunk of chunks)
    for (const m of chunk.matchAll(/^\[(?:White|Black) "([^"\n]+)"\]/gm))
      players.set(m[1], (players.get(m[1]) || 0) + 1);
  const user =
    username || [...players].sort((a, b) => b[1] - a[1])[0]?.[0] || "";
  const games: Game[] = [];
  const errors: { record: number; message: string }[] = [];
  const ids = new Set<string>();
  let duplicates = 0;
  chunks.forEach((pgn, index) => {
    try {
      const chess = new Chess();
      chess.loadPgn(pgn);
      const h = chess.getHeaders();
      if (!h.White || !h.Black || !h.Date)
        throw Error("Missing player/date headers");
      if (!/^\d{4}\.\d{2}\.\d{2}$/.test(h.Date))
        throw Error("Invalid game date");
      if (!["1-0", "0-1", "1/2-1/2"].includes(h.Result))
        throw Error("Only completed games can be imported");
      const ending = pgn
        .replace(/\{[^}]*\}/g, "")
        .trim()
        .match(/(1-0|0-1|1\/2-1\/2|\*)\s*$/)?.[1];
      if (ending !== h.Result)
        throw Error("Movetext result does not match header");
      if (h.Variant && h.Variant.toLowerCase() !== "standard")
        throw Error("Only standard chess is supported");
      const color =
        h.White.toLowerCase() === user.toLowerCase()
          ? "w"
          : h.Black.toLowerCase() === user.toLowerCase()
            ? "b"
            : null;
      if (!color) throw Error("Game does not belong to " + user);
      const moves = chess.history();
      if (!moves.length) throw Error("Game contains no moves");
      const date =
        h.Date.replaceAll(".", "-") +
        "T" +
        (
          h.UTCTime ||
          h.EndTime?.match(/\d{1,2}:\d{2}:\d{2}/)?.[0] ||
          "12:00:00"
        ).padStart(8, "0") +
        "Z";
      if (!Number.isFinite(Date.parse(date))) throw Error("Invalid date/time");
      const id = hash(
        [
          h.White.toLowerCase(),
          h.Black.toLowerCase(),
          h.Date,
          h.UTCTime || h.EndTime || "",
          h.TimeControl,
          h.Result,
          h.FEN || "",
          moves.join(" "),
        ].join("|"),
      );
      if (ids.has(id)) {
        duplicates++;
        return;
      }
      ids.add(id);
      const tc = h.TimeControl?.match(/^(\d+)(?:\+(\d+))?$/);
      const seconds = tc ? +tc[1] + 40 * +(tc[2] || 0) : 0;
      games.push({
        id,
        pgn,
        headers: h,
        moves,
        date,
        color,
        rating: Number(h[color === "w" ? "WhiteElo" : "BlackElo"]) || 0,
        opponent: h[color === "w" ? "Black" : "White"],
        result:
          h.Result === "1/2-1/2"
            ? "draw"
            : h.Result === (color === "w" ? "1-0" : "0-1")
              ? "win"
              : "loss",
        rapid: seconds >= 600 && seconds < 3600,
      });
    } catch (e) {
      errors.push({ record: index + 1, message: String(e) });
    }
  });
  games.sort(
    (a, b) => a.date.localeCompare(b.date) || a.id.localeCompare(b.id),
  );
  return { username: user, games, errors, duplicates, records: chunks.length };
}
export function summarize(games: Game[]) {
  const rated = games.filter((g) => g.rapid && g.rating);
  const recent = rated.slice(-150);
  const prior = rated.slice(-300, -150);
  const cohort = (a: Game[]) => ({
    games: a.length,
    wins: a.filter((g) => g.result === "win").length,
    losses: a.filter((g) => g.result === "loss").length,
    draws: a.filter((g) => g.result === "draw").length,
    averageRating: a.length
      ? Math.round(a.reduce((s, g) => s + g.rating, 0) / a.length)
      : 0,
    score: a.length
      ? Math.round(
          (100 *
            a.reduce(
              (s, g) =>
                s + (g.result === "win" ? 1 : g.result === "draw" ? 0.5 : 0),
              0,
            )) /
            a.length,
        )
      : 0,
  });
  return {
    total: games.length,
    rapid: rated.length,
    firstDate: games[0]?.date,
    lastDate: games.at(-1)?.date,
    firstRating: rated[0]?.rating,
    currentRating: rated.at(-1)?.rating,
    peakRating: Math.max(0, ...rated.map((g) => g.rating)),
    recent: cohort(recent),
    prior: cohort(prior),
    ratingHistory: rated.map((g) => ({
      date: g.date,
      rating: g.rating,
      id: g.id,
    })),
  };
}
