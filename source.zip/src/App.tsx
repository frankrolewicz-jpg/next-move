import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Chessboard } from "react-chessboard";
import {
  ArrowRight,
  ArrowUpRight,
  BookOpen,
  ChartNoAxesCombined,
  Check,
  ChevronRight,
  Clock,
  Download,
  Flame,
  GraduationCap,
  Home,
  Lightbulb,
  Pause,
  Play,
  RefreshCw,
  ShieldCheck,
  Target,
  Upload,
  WifiOff,
  X,
} from "lucide-react";
import {
  bootstrap,
  snapshot,
  db,
  dayKey,
  recordAttempt,
  addTime,
  importPgn,
  exportBackup,
  restoreBackup,
  saveAnalysis,
} from "./lib/db";
import { summarize } from "./lib/pgn";
import { analyzeGame, chooseLessons } from "./lib/teaching";
import { Engine } from "./lib/engine";
import { syncChessCom } from "./lib/sync";
import type { Lesson, Review } from "./lib/types";
import LessonPlayer from "./components/LessonPlayer";
type Data = Awaited<ReturnType<typeof snapshot>>;
const tabs = [
  { id: "today", label: "Today", icon: Home },
  { id: "train", label: "Practice", icon: GraduationCap },
  { id: "progress", label: "Progress", icon: ChartNoAxesCombined },
  { id: "games", label: "My games", icon: BookOpen },
] as const;
type Tab = (typeof tabs)[number]["id"];
const empty: Data = {
  games: [],
  lessons: [],
  reviews: [],
  sessions: [],
  analysis: [],
};
const themeCopy: Record<string, string> = {
  "Material under threat": "Notice what your opponent can take.",
  "Piece development": "Bring your minor pieces into play.",
  "Open-file rook activity": "Look for files where your rooks can work.",
  Calculation: "Compare the strongest reply to each move.",
  "King safety": "Spot forcing threats before they become mate.",
  "Missed capture": "Look for captures before choosing a quiet move.",
  "Missed mate": "Turn a winning attack into checkmate.",
  "Opening decisions": "Build good habits in the first ten moves.",
  "Endgame decisions": "Slow down when only a few pieces remain.",
};
function RatingChart({
  ratings,
  large = false,
}: {
  ratings: number[];
  large?: boolean;
}) {
  if (!ratings.length) return null;
  const lo = Math.min(...ratings) - 35,
    hi = Math.max(...ratings) + 35;
  const points = ratings
    .map(
      (r, i) =>
        `${(i / (ratings.length - 1 || 1)) * 600},${150 - ((r - lo) / (hi - lo)) * 125}`,
    )
    .join(" ");
  return (
    <svg
      viewBox="0 0 600 180"
      className={"rating-chart " + (large ? "large" : "")}
      role="img"
      aria-label={`Rating history from ${ratings[0]} to ${ratings.at(-1)}`}
    >
      <defs>
        <linearGradient id="area" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#6c9a83" stopOpacity=".25" />
          <stop offset="100%" stopColor="#6c9a83" stopOpacity="0" />
        </linearGradient>
      </defs>
      {[35, 90, 145].map((y) => (
        <line
          key={y}
          x1="0"
          x2="600"
          y1={y}
          y2={y}
          stroke="#e6e9e2"
          strokeDasharray="4 5"
        />
      ))}
      <polygon points={`0,180 ${points} 600,180`} fill="url(#area)" />
      <polyline
        points={points}
        fill="none"
        stroke="#426f5a"
        strokeWidth={large ? 2 : 3}
        strokeLinejoin="round"
      />
    </svg>
  );
}
export default function App() {
  const [data, setData] = useState<Data>(empty),
    [loaded, setLoaded] = useState(false),
    [fatal, setFatal] = useState(""),
    [tab, setTab] = useState<Tab>("today"),
    [notice, setNotice] = useState(""),
    [busy, setBusy] = useState(""),
    [install, setInstall] = useState(false),
    [offline, setOffline] = useState(!navigator.onLine),
    [offlineReady, setOfflineReady] = useState(false),
    [autoSync, setAutoSync] = useState(false),
    [active, setActive] = useState<Lesson | null>(null),
    [running, setRunning] = useState(false),
    [elapsed, setElapsed] = useState(0),
    [query, setQuery] = useState(""),
    [now, setNow] = useState(Date.now());
  const analysisEngine = useRef<Engine | null>(null),
    stop = useRef(false),
    timerDelta = useRef(0),
    syncLock = useRef(false);
  const importRef = useRef<HTMLInputElement>(null),
    backupRef = useRef<HTMLInputElement>(null);
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 30000);
    return () => clearInterval(t);
  }, []);
  const reload = useCallback(async () => setData(await snapshot()), []);
  useEffect(() => {
    let cancelled = false;
    bootstrap()
      .then(async () => {
        const s = await snapshot();
        const d = await db();
        if (!cancelled) {
          setData(s);
          setAutoSync(Boolean(await d.get("settings", "autoSync")));
          setElapsed(s.sessions.find((x) => x.day === dayKey())?.seconds || 0);
          setLoaded(true);
        }
      })
      .catch((e) => setFatal(String(e)));
    return () => {
      cancelled = true;
    };
  }, []);
  useEffect(() => {
    const handler = () => setOffline(!navigator.onLine);
    window.addEventListener("online", handler);
    window.addEventListener("offline", handler);
    if ("serviceWorker" in navigator)
      navigator.serviceWorker.ready
        .then(async () => {
          const names = await caches.keys();
          setOfflineReady(names.some((n) => n.startsWith("next-move-")));
        })
        .catch(() => {});
    return () => {
      window.removeEventListener("online", handler);
      window.removeEventListener("offline", handler);
      analysisEngine.current?.close();
    };
  }, []);
  async function sync(force = false) {
    if (syncLock.current || analysisEngine.current) return;
    syncLock.current = true;
    setBusy("Checking Chess.com…");
    try {
      const message = await syncChessCom(setBusy, force);
      setNotice(message);
      await reload();
    } catch (e) {
      setNotice(
        "Sync unavailable: " +
          String(e) +
          ". Local PGN import is available below.",
      );
    } finally {
      syncLock.current = false;
      setBusy("");
    }
  }
  useEffect(() => {
    if (!loaded || !autoSync) return;
    const check = () => {
      if (document.visibilityState === "visible" && navigator.onLine)
        void sync();
    };
    check();
    document.addEventListener("visibilitychange", check);
    window.addEventListener("online", check);
    return () => {
      document.removeEventListener("visibilitychange", check);
      window.removeEventListener("online", check);
    };
  }, [loaded, autoSync]);
  useEffect(() => {
    if (!running || tab !== "train") return;
    const handle = setInterval(() => {
      if (document.visibilityState !== "visible") return;
      setElapsed((s) => s + 1);
      timerDelta.current++;
      if (timerDelta.current >= 15) {
        const delta = timerDelta.current;
        timerDelta.current = 0;
        void addTime(delta).catch((e) => setNotice(String(e)));
      }
    }, 1000);
    const flush = () => {
      if (timerDelta.current) {
        const delta = timerDelta.current;
        timerDelta.current = 0;
        void addTime(delta)
          .then(reload)
          .catch((e) => setNotice(String(e)));
      }
    };
    window.addEventListener("pagehide", flush);
    return () => {
      clearInterval(handle);
      window.removeEventListener("pagehide", flush);
      flush();
    };
  }, [running, tab, reload]);
  const summary = useMemo(() => summarize(data.games), [data.games]);
  const queue = useMemo(
    () => chooseLessons(data.lessons, data.reviews, data.games, now),
    [data, now],
  );
  const reviewMap = useMemo(
    () => new Map(data.reviews.map((r) => [r.id, r])),
    [data.reviews],
  );
  const currentIds = useMemo(
    () =>
      new Set(
        data.games
          .filter((g) => g.rapid)
          .slice(-150)
          .map((g) => g.id),
      ),
    [data.games],
  );
  const priorities = useMemo(() => {
    const count = new Map<
      string,
      { count: number; games: Set<string>; lapses: number }
    >();
    for (const l of data.lessons)
      if (currentIds.has(l.gameId)) {
        const item = count.get(l.theme) || {
          count: 0,
          games: new Set<string>(),
          lapses: 0,
        };
        item.count++;
        item.games.add(l.gameId);
        item.lapses += reviewMap.get(l.id)?.lapses || 0;
        count.set(l.theme, item);
      }
    return [...count].sort(
      (a, b) => b[1].count + b[1].lapses * 2 - (a[1].count + a[1].lapses * 2),
    );
  }, [data.lessons, currentIds, reviewMap]);
  const due = data.reviews.filter((r) => r.due <= Date.now()).length;
  const mastered = data.reviews.filter((r) => r.successes >= 3).length;
  const today = data.sessions.find((s) => s.day === dayKey());
  const covered = data.analysis.filter((r) => currentIds.has(r.id)).length;
  const focus = priorities[0]?.[0] || "Your next decision";
  const viewedGames = data.games
    .filter(
      (g) => !query || g.opponent.toLowerCase().includes(query.toLowerCase()),
    )
    .slice()
    .reverse()
    .slice(0, 60);
  function start(theme?: string) {
    const next = queue.find((l) => !theme || l.theme === theme);
    if (!next) {
      setNotice(
        "You’re caught up for this topic. Review cards return when they’re due.",
      );
      return;
    }
    setActive(next);
    setTab("train");
    setRunning(true);
  }
  async function complete(review: Review, correct: boolean) {
    await recordAttempt(review, correct);
    await reload();
  }
  function next() {
    const nextLesson = queue.find((l) => l.id !== active?.id);
    setActive(nextLesson || null);
  }
  async function analyze() {
    if (busy) return;
    stop.current = false;
    const existing = new Set(data.analysis.map((a) => a.id));
    const games = data.games
      .filter((g) => g.rapid && !existing.has(g.id))
      .slice(-150)
      .reverse();
    if (!games.length) {
      setNotice("All imported rapid games have already been analyzed.");
      return;
    }
    analysisEngine.current = new Engine();
    try {
      for (let i = 0; i < games.length; i++) {
        if (stop.current) break;
        setBusy(`Analyzing game ${i + 1}/${games.length} on this device…`);
        const result = await analyzeGame(games[i], (fen, depth) =>
          analysisEngine.current!.evaluate(fen, depth),
        );
        await saveAnalysis(games[i], result.lessons, result.positions);
        await reload();
      }
      setNotice(
        stop.current
          ? "Analysis paused. Completed games are saved."
          : "Analysis complete. New lessons are ready.",
      );
    } catch (e) {
      setNotice(
        stop.current
          ? "Analysis paused. Completed games are saved."
          : String(e),
      );
    } finally {
      analysisEngine.current?.close();
      analysisEngine.current = null;
      setBusy("");
    }
  }
  async function readFile(file: File | undefined, backup = false) {
    if (!file) return;
    setBusy(backup ? "Restoring progress…" : "Validating every move…");
    try {
      if (file.size > 25 * 1024 * 1024)
        throw Error("Please use a file under 25 MB.");
      const result = backup
        ? await restoreBackup(await file.text())
        : await importPgn(await file.text());
      setNotice(
        `${result.added} games added · ${result.duplicates} duplicates skipped · ${result.rejected} rejected.${backup ? " Progress restored. Use Analyze to regenerate any non-bundled lessons." : ""}${result.errors[0] ? " First rejection: " + result.errors[0].message : ""}`,
      );
      await reload();
      const s = await snapshot();
      setElapsed(s.sessions.find((x) => x.day === dayKey())?.seconds || 0);
    } catch (e) {
      setNotice(String(e));
    } finally {
      setBusy("");
      if (importRef.current) importRef.current.value = "";
      if (backupRef.current) backupRef.current.value = "";
    }
  }
  async function backup() {
    try {
      const url = URL.createObjectURL(
        new Blob([await exportBackup()], { type: "application/json" }),
      );
      const a = document.createElement("a");
      a.href = url;
      a.download = `next-move-backup-${dayKey()}.json`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      setNotice("Backup downloaded. Keep it somewhere safe.");
    } catch (e) {
      setNotice(String(e));
    }
  }
  if (fatal)
    return (
      <main className="loading">
        <h1>We couldn’t open your training library.</h1>
        <p>{fatal}</p>
        <button className="primary" onClick={() => location.reload()}>
          Retry
        </button>
      </main>
    );
  if (!loaded)
    return (
      <main className="loading">
        <div className="brand-mark">♞</div>
        <h1>Getting your board ready.</h1>
        <p>Loading your games and verified lessons onto this device…</p>
      </main>
    );
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <a
          className="brand"
          href="#"
          onClick={(e) => {
            e.preventDefault();
            setTab("today");
          }}
        >
          <span className="brand-mark">♞</span>
          <span>
            next move
            <span className="brand-sub">YOUR PERSONAL CHESS COACH</span>
          </span>
        </a>
        <div className="nav-label">YOUR TRAINING SPACE</div>
        <nav>
          {tabs.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              className={tab === id ? "selected" : ""}
              onClick={() => setTab(id)}
            >
              <Icon size={20} />
              <span>{label}</span>
              {id === "train" && due > 0 && <small>{due}</small>}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="private-note">
            <ShieldCheck size={20} />
            <div>
              Made from your games.<small>No account. No tracking.</small>
            </div>
          </div>
          <button className="install-link" onClick={() => setInstall(true)}>
            <Download size={17} /> Add to home screen <ArrowUpRight size={15} />
          </button>
          <div className="profile">
            <span className="avatar">FR</span>
            <span>
              Frankrolewicz<small>On the road to 1400</small>
            </span>
          </div>
        </div>
      </aside>
      <div className="main-shell">
        <header className="topbar">
          <span>{tabs.find((t) => t.id === tab)?.label}</span>
          <div>
            <span className="local-status">
              <span className="status-dot" />
              {offline
                ? "Offline"
                : offlineReady
                  ? "Offline ready"
                  : "On-device coach"}
            </span>
            <button
              aria-label="Install on iPhone"
              className="icon-button mobile-install"
              onClick={() => setInstall(true)}
            >
              <Download size={19} />
            </button>
            <span className="top-avatar">FR</span>
          </div>
        </header>
        <main className="content">
          {notice && (
            <div className="notice" role="status">
              <span>{notice}</span>
              <button aria-label="Dismiss notice" onClick={() => setNotice("")}>
                <X size={17} />
              </button>
            </div>
          )}
          {offline && (
            <div className="offline-banner">
              <WifiOff size={16} /> You’re offline. Your saved lessons still
              work.
            </div>
          )}
          {tab === "today" && (
            <>
              <div className="page-heading">
                <div>
                  <div className="eyebrow">A LITTLE BETTER, EVERY DAY</div>
                  <h1>Your next move starts here.</h1>
                  <p>
                    Welcome back, Frank. Let’s turn your games into better
                    instincts.
                  </p>
                </div>
                <span className="date-label">
                  {new Date().toLocaleDateString(undefined, {
                    weekday: "short",
                    month: "short",
                    day: "numeric",
                  })}
                </span>
              </div>
              <section className="hero">
                <div className="hero-copy">
                  <span className="hero-tag">
                    <span /> YOUR DAILY PRACTICE
                  </span>
                  <h2>
                    Small steps.
                    <br />
                    Stronger chess.
                  </h2>
                  <p>
                    Today, work on <strong>{focus.toLowerCase()}</strong> with
                    positions from games you actually played.
                  </p>
                  <button className="cream-button" onClick={() => start()}>
                    Start today’s session <ArrowRight size={19} />
                  </button>
                  <div className="hero-meta">
                    <Clock size={15} />
                    <span>About 20 minutes</span>
                    <span className="dot-separator">·</span>
                    <span>
                      {due
                        ? `${due} reviews due`
                        : "Built around your recent games"}
                    </span>
                  </div>
                </div>
                <div className="hero-board">
                  <div className="mini-board">
                    <Chessboard
                      options={{
                        id: "preview",
                        position: queue[0]?.fen || "start",
                        boardOrientation:
                          queue[0]?.color === "b" ? "black" : "white",
                        allowDragging: false,
                        allowDrawingArrows: false,
                        showNotation: false,
                        darkSquareStyle: { backgroundColor: "#739183" },
                        lightSquareStyle: { backgroundColor: "#ede8d5" },
                      }}
                    />
                  </div>
                  <div className="board-sticker">
                    <span>↗</span> Your games. Your next breakthrough.
                  </div>
                </div>
              </section>
              <div className="stats-grid">
                <div className="card stat">
                  <span>
                    Latest rapid rating <Target size={17} />
                  </span>
                  <strong>{summary.currentRating}</strong>
                  <small>
                    Goal <b>1400</b>{" "}
                    <span className="subtle">· header rating</span>
                  </small>
                </div>
                <div className="card stat">
                  <span>
                    Recent average <ChartNoAxesCombined size={17} />
                  </span>
                  <strong>
                    {summary.recent.averageRating}
                    <em>
                      +
                      {summary.recent.averageRating -
                        summary.prior.averageRating}
                    </em>
                  </strong>
                  <small>vs. previous {summary.prior.games} games</small>
                </div>
                <div className="card stat">
                  <span>
                    Positions mastered <Check size={17} />
                  </span>
                  <strong>
                    {mastered}
                    <em className="neutral">/ {data.lessons.length}</em>
                  </strong>
                  <small>Three successful spaced reviews</small>
                </div>
              </div>
              <div className="dashboard-grid">
                <section className="card plan">
                  <div className="section-title">
                    <h2>Your 20-minute plan</h2>
                    <span className="badge">TODAY</span>
                  </div>
                  <p className="muted">
                    A little recall. A focused challenge. A lasting habit.
                  </p>
                  {[
                    {
                      icon: RefreshCw,
                      title: "Bring it back",
                      text: due
                        ? `${due} familiar positions ready to revisit`
                        : "Warm up with a position from your games",
                      time: "3 min",
                    },
                    {
                      icon: Target,
                      title: "Work on your weak spot",
                      text: themeCopy[focus],
                      time: "12 min",
                    },
                    {
                      icon: Lightbulb,
                      title: "Make it stick",
                      text: "Explain the threat, then replay the better line",
                      time: "5 min",
                    },
                  ].map(({ icon: Icon, title, text, time }, i) => (
                    <div className="plan-row" key={title}>
                      <span className={"plan-icon p" + i}>
                        <Icon size={20} />
                      </span>
                      <div>
                        <h3>{title}</h3>
                        <p>{text}</p>
                      </div>
                      <span>{time}</span>
                    </div>
                  ))}
                  <button
                    className="text-button plan-cta"
                    onClick={() => start()}
                  >
                    Let’s get to the board <ArrowRight size={17} />
                  </button>
                </section>
                <section className="card priorities">
                  <div className="section-title">
                    <h2>Your focus areas</h2>
                    <Target size={18} />
                  </div>
                  <p className="muted">From your latest 150 rapid games.</p>
                  {priorities.slice(0, 3).map(([theme, item], i) => (
                    <button
                      className="focus-row"
                      key={theme}
                      onClick={() => start(theme)}
                    >
                      <span className="focus-number">0{i + 1}</span>
                      <div>
                        <h3>{theme}</h3>
                        <p>
                          {item.games.size} games · {item.count} verified
                          positions
                        </p>
                        <div className="focus-track">
                          <span
                            style={{
                              width:
                                Math.max(
                                  12,
                                  (item.count /
                                    (priorities[0]?.[1].count || 1)) *
                                    100,
                                ) + "%",
                            }}
                          />
                        </div>
                      </div>
                      <ChevronRight size={17} />
                    </button>
                  ))}
                  <div className="coverage-note">
                    <ShieldCheck size={14} />
                    {covered}/150 games analyzed · depth 12 verification
                  </div>
                </section>
              </div>
              <section className="card journey">
                <div>
                  <div className="eyebrow">THE LONG GAME</div>
                  <h2>Progress is more than a rating.</h2>
                  <p className="muted">
                    {summary.total.toLocaleString()} games. Every mistake is a
                    position you can learn from.
                  </p>
                  <button
                    className="text-button"
                    onClick={() => setTab("progress")}
                  >
                    See your progress <ArrowRight size={16} />
                  </button>
                </div>
                <div>
                  <RatingChart
                    ratings={summary.ratingHistory
                      .slice(-150)
                      .map((r) => r.rating)}
                  />
                  <div className="chart-labels">
                    <span>150 rapid games ago</span>
                    <span>Latest game</span>
                  </div>
                </div>
              </section>
            </>
          )}
          {tab === "train" && (
            <>
              <div className="page-heading">
                <div>
                  <div className="eyebrow">THINK FIRST. THEN MOVE.</div>
                  <h1>Your practice board.</h1>
                  <p>Real positions. Useful habits. One decision at a time.</p>
                </div>
                <div className="session-clock">
                  <Clock size={18} />
                  <span>
                    {Math.floor(elapsed / 60)}:
                    {String(elapsed % 60).padStart(2, "0")} / 20:00
                  </span>
                  <button
                    aria-label={running ? "Pause timer" : "Resume timer"}
                    onClick={() => setRunning(!running)}
                  >
                    {running ? <Pause size={18} /> : <Play size={18} />}
                  </button>
                </div>
              </div>
              <p className="phase-guidance">
                {elapsed < 180
                  ? "Warm up: recall the threat before choosing your move."
                  : elapsed < 900
                    ? "Focus: compare two candidate moves and calculate the strongest reply."
                    : "Reflect: say why the move works, then replay both continuations before moving on."}
              </p>
              <div className="session-phases">
                {["Recall · 3 min", "Focus · 12 min", "Reflect · 5 min"].map(
                  (s, i) => (
                    <span
                      key={s}
                      className={
                        (elapsed < 180 ? 0 : elapsed < 900 ? 1 : 2) === i
                          ? "current"
                          : ""
                      }
                    >
                      {i + 1}. {s}
                    </span>
                  ),
                )}
              </div>
              {elapsed >= 1200 && (
                <div className="notice">
                  <Check size={18} />
                  <span>
                    Twenty minutes invested. You can finish here or keep
                    practicing.
                  </span>
                  <button
                    onClick={() => {
                      setRunning(false);
                      setTab("progress");
                    }}
                  >
                    Finish
                  </button>
                </div>
              )}
              {active ? (
                <LessonPlayer
                  key={active.id}
                  lesson={active}
                  review={reviewMap.get(active.id)}
                  onComplete={complete}
                  onNext={next}
                />
              ) : (
                <section className="card empty-state">
                  <GraduationCap size={42} />
                  <h2>
                    {queue.length
                      ? "Ready for your next decision?"
                      : "You’re caught up."}
                  </h2>
                  <p>
                    {queue.length
                      ? `${queue.length} new or due positions are ready. Your recent weaknesses get priority.`
                      : "Your reviews will return on schedule. Import completed games for new lessons."}
                  </p>
                  {queue.length > 0 && (
                    <button className="primary" onClick={() => start()}>
                      Begin practice <ArrowRight size={18} />
                    </button>
                  )}
                </section>
              )}
            </>
          )}
          {tab === "progress" && (
            <>
              <div className="page-heading">
                <div>
                  <div className="eyebrow">YOUR ROAD TO 1400</div>
                  <h1>Build habits. Watch them compound.</h1>
                  <p>
                    Your game history gives us the baseline. Your practice
                    shapes what comes next.
                  </p>
                </div>
              </div>
              <div className="stats-grid">
                <div className="card stat">
                  <span>Latest recorded rating</span>
                  <strong>{summary.currentRating}</strong>
                  <small>Peak {summary.peakRating} · goal 1400</small>
                </div>
                <div className="card stat">
                  <span>
                    Practice today <Flame size={17} />
                  </span>
                  <strong>
                    {Math.floor(elapsed / 60)}
                    <em className="neutral">minutes</em>
                  </strong>
                  <small>{today?.attempts || 0} positions completed</small>
                </div>
                <div className="card stat">
                  <span>Unassisted recall</span>
                  <strong>
                    {data.sessions.reduce((a, s) => a + s.attempts, 0)
                      ? Math.round(
                          (data.sessions.reduce((a, s) => a + s.correct, 0) /
                            data.sessions.reduce((a, s) => a + s.attempts, 0)) *
                            100,
                        ) + "%"
                      : "—"}
                  </strong>
                  <small>First try, without hints</small>
                </div>
              </div>
              <section className="card history-chart">
                <div className="section-title">
                  <h2>Your rapid rating history</h2>
                  <span className="badge">{summary.rapid} GAMES</span>
                </div>
                <RatingChart
                  ratings={summary.ratingHistory.map((r) => r.rating)}
                  large
                />
                <div className="chart-labels">
                  <span>
                    {summary.firstDate?.slice(0, 10)} · {summary.firstRating}
                  </span>
                  <span>Peak {summary.peakRating}</span>
                  <span>
                    {summary.lastDate?.slice(0, 10)} · {summary.currentRating}
                  </span>
                </div>
                <p className="fine-print">
                  Ratings are recorded in each PGN header, not your live
                  Chess.com rating. Horizontal spacing is by game, not calendar
                  time.
                </p>
              </section>
              <div className="dashboard-grid">
                <section className="card padded">
                  <h2>What’s changing?</h2>
                  <div className="comparison">
                    <span>Rapid games</span>
                    <b>Previous 150</b>
                    <b>Latest 150</b>
                    <span>Average rating</span>
                    <strong>{summary.prior.averageRating}</strong>
                    <strong>{summary.recent.averageRating}</strong>
                    <span>Score rate</span>
                    <strong>{summary.prior.score}%</strong>
                    <strong>{summary.recent.score}%</strong>
                    <span>Wins / losses / draws</span>
                    <span>
                      {summary.prior.wins} / {summary.prior.losses} /{" "}
                      {summary.prior.draws}
                    </span>
                    <span>
                      {summary.recent.wins} / {summary.recent.losses} /{" "}
                      {summary.recent.draws}
                    </span>
                  </div>
                  <p className="fine-print">
                    Score rate counts a draw as half a point. Rating and results
                    alone do not prove that a specific skill has improved.
                  </p>
                </section>
                <section className="card padded">
                  <h2>What to work on next</h2>
                  {priorities.map(([theme, item]) => (
                    <div className="insight" key={theme}>
                      <b>{theme}</b>
                      <p>
                        {themeCopy[theme]}{" "}
                        <span>
                          {item.count} selected positions; {item.lapses}{" "}
                          practice lapses.
                        </span>
                      </p>
                    </div>
                  ))}
                  <p className="fine-print">
                    Screened at depth 8; up to 3 significant positions per game
                    rechecked at depth 12. Counts describe selected lessons, not
                    every error. Development and open-file labels use explicit
                    board facts. Other strategic labels describe the game phase;
                    broader positional diagnoses are not inferred.
                  </p>
                </section>
              </div>
            </>
          )}
          {tab === "games" && (
            <>
              <div className="page-heading">
                <div>
                  <div className="eyebrow">THE SOURCE OF YOUR LESSONS</div>
                  <h1>Your games, in one place.</h1>
                  <p>
                    {data.games.length.toLocaleString()} validated games · saved
                    on this device
                  </p>
                </div>
                <button
                  className="primary"
                  disabled={!!busy}
                  onClick={() => importRef.current?.click()}
                >
                  <Upload size={17} /> Import PGN
                </button>
              </div>
              <input
                ref={importRef}
                type="file"
                accept=".pgn,.txt"
                hidden
                onChange={(e) => void readFile(e.target.files?.[0])}
              />
              <input
                ref={backupRef}
                type="file"
                accept=".json"
                hidden
                onChange={(e) => void readFile(e.target.files?.[0], true)}
              />
              <section className="card sync-card">
                <div className="sync-title">
                  <span className="plan-icon p0">
                    <RefreshCw size={22} />
                  </span>
                  <div>
                    <h2>Keep your coach up to date</h2>
                    <p>Import completed Chess.com games for Frankrolewicz.</p>
                  </div>
                </div>
                <div className="sync-actions">
                  <button
                    className="secondary"
                    disabled={!!busy || offline}
                    onClick={() => void sync(true)}
                  >
                    <RefreshCw size={16} /> Sync games
                  </button>
                  <button
                    className="primary"
                    disabled={!!busy}
                    onClick={() => void analyze()}
                  >
                    Analyze unreviewed games <ArrowRight size={16} />
                  </button>
                </div>
                <label className="toggle-row">
                  <input
                    type="checkbox"
                    checked={autoSync}
                    onChange={(e) => {
                      setAutoSync(e.target.checked);
                      void db().then((d) =>
                        d.put("settings", e.target.checked, "autoSync"),
                      );
                    }}
                  />{" "}
                  Check for new games when I open the app (at most every 6
                  hours)
                </label>
                <p className="fine-print">
                  Only completed games. Runs while this app is open; iPhone does
                  not guarantee background updates. Analysis runs locally and
                  may use battery. No live-game assistance. Not affiliated with
                  Chess.com.
                </p>
                {busy && (
                  <div className="analysis-status" role="status">
                    <span className="spinner" />
                    {busy}
                    {analysisEngine.current && (
                      <button
                        onClick={() => {
                          stop.current = true;
                          analysisEngine.current?.close();
                        }}
                      >
                        Stop
                      </button>
                    )}
                  </div>
                )}
              </section>
              <section className="card game-library">
                <div className="section-title">
                  <h2>Game library</h2>
                  <input
                    aria-label="Search opponents"
                    placeholder="Search opponents…"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                  />
                </div>
                <div className="game-table">
                  <div className="game-row table-head">
                    <span>Opponent</span>
                    <span>Result</span>
                    <span>Rating</span>
                    <span>Date</span>
                    <span>Lessons</span>
                  </div>
                  {viewedGames.map((g) => {
                    const lessons = data.lessons.filter(
                      (l) => l.gameId === g.id,
                    );
                    return (
                      <div key={g.id} className="game-row">
                        <span className="opponent">
                          <span className={"side-dot " + g.color} />
                          <strong>{g.opponent}</strong>
                        </span>
                        <span className={"result " + g.result}>{g.result}</span>
                        <span>{g.rating}</span>
                        <span>
                          {new Date(g.date).toLocaleDateString(undefined, {
                            month: "short",
                            day: "numeric",
                            year: "2-digit",
                          })}
                        </span>
                        <button
                          disabled={!lessons.length}
                          onClick={() => {
                            setActive(lessons[0]);
                            setTab("train");
                            setRunning(true);
                          }}
                        >
                          {lessons.length ? `${lessons.length} lessons` : "—"}
                          {lessons.length > 0 && <ChevronRight size={14} />}
                        </button>
                      </div>
                    );
                  })}
                </div>
                <p className="fine-print">
                  Showing the latest {viewedGames.length} matching games. All{" "}
                  {data.games.length} games are stored locally.
                </p>
              </section>
              <section className="card backup-card">
                <div>
                  <h2>Keep a copy of your progress</h2>
                  <p className="muted">
                    Browser storage can be cleared. Save a backup before
                    switching devices.
                  </p>
                </div>
                <div>
                  <button className="secondary" onClick={() => void backup()}>
                    <Download size={16} /> Export backup
                  </button>
                  <button
                    className="text-button"
                    disabled={!!busy}
                    onClick={() => backupRef.current?.click()}
                  >
                    Restore backup
                  </button>
                </div>
              </section>
            </>
          )}
          <footer>
            <span>♞ next move</span>
            <span>Built from your games. Powered by local Stockfish.</span>
            <span>Free · No account · No paid APIs</span>
            <a
              href={import.meta.env.BASE_URL + "engine/SOURCE.txt"}
              target="_blank"
              rel="noreferrer"
            >
              Engine source &amp; license
            </a>
          </footer>
        </main>
      </div>
      <nav className="bottom-nav">
        {tabs.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            className={tab === id ? "selected" : ""}
            onClick={() => setTab(id)}
          >
            <Icon size={21} />
            <span>{label}</span>
          </button>
        ))}
      </nav>
      {install && (
        <div className="modal-backdrop" onClick={() => setInstall(false)}>
          <section
            className="modal card"
            role="dialog"
            aria-modal="true"
            aria-label="Install on iPhone"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              className="modal-close icon-button"
              aria-label="Close installation instructions"
              onClick={() => setInstall(false)}
            >
              <X size={20} />
            </button>
            <span className="brand-mark">♞</span>
            <h2>
              Your daily coach.
              <br />
              One tap away.
            </h2>
            <p>On your iPhone, open the hosted HTTPS address in Safari.</p>
            <ol>
              <li>
                Tap the <strong>Share</strong> button.
              </li>
              <li>
                Choose <strong>Add to Home Screen</strong>.
              </li>
              <li>
                Tap <strong>Add</strong>, then open Next Move.
              </li>
            </ol>
            <p className="fine-print">
              Let the first load finish online to save the engine and lessons.{" "}
              {location.protocol === "https:"
                ? "Open the installed app once online and wait for Offline ready before disconnecting."
                : "This local preview has not been deployed; a hosted HTTPS address is needed for installation on your iPhone."}
            </p>
            <button className="primary full" onClick={() => setInstall(false)}>
              Got it <Check size={18} />
            </button>
          </section>
        </div>
      )}
    </div>
  );
}
