import { useEffect, useRef, useState } from "react";
import { Chess, type Square } from "chess.js";
import { Chessboard } from "react-chessboard";
import {
  ArrowRight,
  ArrowLeft,
  Lightbulb,
  Check,
  RotateCcw,
  ChevronRight,
} from "lucide-react";
import { Engine } from "../lib/engine";
import { playUci, scheduleReview } from "../lib/teaching";
import type { Lesson, Review } from "../lib/types";
export default function LessonPlayer({
  lesson,
  review,
  onComplete,
  onNext,
}: {
  lesson: Lesson;
  review?: Review;
  onComplete: (r: Review, correct: boolean) => Promise<void>;
  onNext: () => void;
}) {
  const [fen, setFen] = useState(lesson.fen),
    [selected, setSelected] = useState<string | null>(null),
    [hint, setHint] = useState(0),
    [mistakes, setMistakes] = useState(0),
    [attempted, setAttempted] = useState(false),
    [revealed, setRevealed] = useState(false),
    [message, setMessage] = useState(""),
    [busy, setBusy] = useState(false),
    [san, setSan] = useState(""),
    [promotion, setPromotion] = useState("q"),
    [lineType, setLineType] = useState<"best" | "played">("best"),
    [step, setStep] = useState(0);
  const engine = useRef<Engine | null>(null),
    lock = useRef(false),
    mounted = useRef(true);
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
      engine.current?.close();
    };
  }, []);
  async function complete(quality: number, success: boolean) {
    await onComplete(scheduleReview(review, lesson.id, quality), success);
    if (!mounted.current) return;
    setRevealed(true);
    setFen(lesson.fen);
    setStep(0);
  }
  async function attempt(from?: string, to?: string) {
    if (revealed || lock.current) return;
    let move;
    const chess = new Chess(lesson.fen);
    try {
      move =
        from && to
          ? chess.move({ from, to, promotion })
          : chess.move(san.trim());
    } catch {
      setMessage(
        "That move is not legal here. Try another square or use standard notation.",
      );
      return;
    }
    setAttempted(true);
    setSelected(null);
    setSan("");
    lock.current = true;
    setBusy(true);
    try {
      let success = move.lan === lesson.best;
      if (!success && !chess.isGameOver()) {
        setMessage("Checking your idea with local Stockfish…");
        engine.current ??= new Engine();
        const alternative = await engine.current.evaluate(chess.fen(), 12);
        success =
          lesson.before.mate !== undefined
            ? lesson.before.mate > 0 &&
              alternative.mate !== undefined &&
              alternative.mate < 0
            : lesson.before.cp + alternative.cp <= 40;
      } else if (chess.isCheckmate()) success = true;
      else if (chess.isDraw())
        success = lesson.before.mate === undefined && lesson.before.cp <= 40;
      if (!mounted.current) return;
      if (success) {
        await complete(mistakes ? 2 : hint ? 3 : 5, !mistakes && !hint);
        setMessage(
          move.lan === lesson.best
            ? "Good find. Now understand why it works."
            : "Your move also holds the evaluation. Compare it with the engine’s preferred line.",
        );
      } else {
        setMistakes((m) => m + 1);
        setMessage(
          `${move.san} gives up too much compared with best play. Reset your thinking: what can your opponent do next?`,
        );
      }
    } catch (e) {
      if (mounted.current) setMessage(String(e));
    } finally {
      lock.current = false;
      if (mounted.current) setBusy(false);
    }
  }
  async function reveal() {
    if (lock.current) return;
    lock.current = true;
    setBusy(true);
    try {
      await complete(1, false);
      setMessage(
        "Study the continuation, then come back to this position. It will return in 10 minutes.",
      );
    } catch (e) {
      setMessage(String(e));
    } finally {
      setBusy(false);
      lock.current = false;
    }
  }
  function click(square: string) {
    if (revealed || busy) return;
    const p = new Chess(lesson.fen).get(square as Square);
    if (p?.color === lesson.color) {
      setSelected(square);
      return;
    }
    if (selected) void attempt(selected, square);
  }
  function replay(type: "best" | "played", n: number) {
    const c = new Chess(lesson.fen);
    if (type === "played") playUci(c, lesson.played);
    const pv = type === "best" ? lesson.before.pv : lesson.after.pv;
    for (const move of pv.slice(0, n)) playUci(c, move);
    setFen(c.fen());
    setStep(n);
    setLineType(type);
  }
  const line = lineType === "best" ? lesson.line : lesson.punishment;
  return (
    <div className="lesson-layout" data-lesson-id={lesson.id}>
      <section>
        <div className="board-top">
          <span>
            <span className={"side-dot " + lesson.color} />
            {lesson.color === "w" ? "White" : "Black"} to move
          </span>
          <span>Move {Math.floor(lesson.ply / 2) + 1}</span>
        </div>
        <div className="board-frame">
          <Chessboard
            options={{
              id: "lesson-board",
              position: fen,
              boardOrientation: lesson.color === "w" ? "white" : "black",
              darkSquareStyle: { backgroundColor: "#78968b" },
              lightSquareStyle: { backgroundColor: "#ecebdc" },
              squareStyles: selected
                ? { [selected]: { backgroundColor: "#e5bc5b" } }
                : {},
              allowDragging: !revealed && !busy,
              allowDrawingArrows: false,
              onSquareClick: ({ square }) => click(square),
              onPieceDrop: ({ sourceSquare, targetSquare }) => {
                if (targetSquare) void attempt(sourceSquare, targetSquare);
                return false;
              },
              animationDurationInMs: 180,
            }}
          />
        </div>
        <div className="board-caption">
          Your game against <strong>{lesson.opponent}</strong>
          <span>
            {new Date(lesson.date).toLocaleDateString(undefined, {
              month: "short",
              day: "numeric",
              year: "numeric",
            })}
          </span>
        </div>
        {revealed && (
          <div className="replay card">
            <div className="segmented">
              <button
                className={lineType === "best" ? "active" : ""}
                onClick={() => replay("best", 0)}
              >
                Better plan
              </button>
              <button
                className={lineType === "played" ? "active" : ""}
                onClick={() => replay("played", 0)}
              >
                After {lesson.playedSan}
              </button>
            </div>
            <p className="notation">
              {line.map((s, i) => (
                <button
                  key={i}
                  className={step === i + 1 ? "active" : ""}
                  onClick={() => replay(lineType, i + 1)}
                >
                  {s}
                </button>
              ))}
            </p>
            <div className="replay-controls">
              <button
                aria-label="Previous move"
                disabled={!step}
                onClick={() => replay(lineType, step - 1)}
              >
                <ArrowLeft size={18} />
              </button>
              <span>
                {step} / {line.length} half-moves
              </span>
              <button
                aria-label="Next move"
                disabled={step === line.length}
                onClick={() => replay(lineType, step + 1)}
              >
                <ArrowRight size={18} />
              </button>
            </div>
          </div>
        )}
      </section>
      <section className="lesson-copy card">
        <div className="eyebrow">
          {revealed ? "THE TAKEAWAY" : "YOUR TURN TO THINK"}
        </div>
        <h2>{revealed ? lesson.theme : "What would you play?"}</h2>
        <p className="muted">
          {revealed
            ? "A decision from your own game, with the evidence behind it."
            : "Take your time. Check the threats, choose a candidate, then look one move further."}
        </p>
        {!revealed && (
          <>
            <div className="attempt-instruction">
              Tap a piece, then its destination. Or drag to move.
            </div>
            <form
              className="move-form"
              onSubmit={(e) => {
                e.preventDefault();
                void attempt();
              }}
            >
              <label htmlFor="move">Enter a move</label>
              <div className="input-row">
                <input
                  id="move"
                  placeholder="e.g. Nf3"
                  value={san}
                  onChange={(e) => setSan(e.target.value)}
                  autoComplete="off"
                  disabled={busy}
                />
                <button
                  className="primary compact"
                  disabled={busy || !san.trim()}
                  type="submit"
                >
                  Try move <ChevronRight size={16} />
                </button>
              </div>
            </form>
            <label className="promotion">
              Promote pawn to{" "}
              <select
                aria-label="Promotion piece"
                value={promotion}
                onChange={(e) => setPromotion(e.target.value)}
              >
                <option value="q">Queen</option>
                <option value="r">Rook</option>
                <option value="b">Bishop</option>
                <option value="n">Knight</option>
              </select>
            </label>
          </>
        )}
        {message && (
          <div
            role="status"
            className={"feedback " + (revealed ? "success" : "")}
          >
            {revealed && <Check size={19} />}
            <span>{message}</span>
          </div>
        )}
        {!revealed ? (
          <>
            <div className="hints">
              {lesson.hints.slice(0, hint).map((h, i) => (
                <p key={h}>
                  <span>{i + 1}</span>
                  {h}
                </p>
              ))}
            </div>
            <button
              className="secondary full"
              onClick={() => setHint((h) => Math.min(3, h + 1))}
              disabled={hint === 3 || busy}
            >
              <Lightbulb size={18} />{" "}
              {hint === 3
                ? "All hints shown"
                : hint
                  ? "Another hint"
                  : "Give me a hint"}
              <span className="push muted">{hint}/3</span>
            </button>
            <button
              className="text-button full"
              disabled={busy || (!attempted && hint < 3)}
              onClick={() => void reveal()}
            >
              Show explanation
            </button>
            <small className="muted">
              Try a move first. Getting it wrong is part of learning.
            </small>
          </>
        ) : (
          <>
            <p className="explanation">{lesson.explanation}</p>
            <div className="evidence">
              <Check size={16} />
              <span>
                Stockfish 17.1 · depth{" "}
                {Math.min(lesson.before.depth, lesson.after.depth)}
                <br />
                Legal continuation checked by chess.js
              </span>
            </div>
            <button className="primary full" onClick={onNext}>
              Next position <ArrowRight size={18} />
            </button>
            <button
              className="text-button full"
              onClick={() => replay("best", 0)}
            >
              <RotateCcw size={15} /> Revisit the starting position
            </button>
          </>
        )}
      </section>
    </div>
  );
}
