import { describe, it, expect, beforeEach } from "vitest";
import "fake-indexeddb/auto";
import { readFileSync } from "node:fs";
import { Chess } from "chess.js";
import { parseGames, summarize } from "../src/lib/pgn";
import { parseInfo, Engine, type Transport } from "../src/lib/engine";
import { chooseLessons, playUci, scheduleReview } from "../src/lib/teaching";
import {
  db,
  importPgn,
  recordAttempt,
  snapshot,
  dayKey,
  restoreBackup,
} from "../src/lib/db";
import type { Game, Lesson, AnalysisRecord } from "../src/lib/types";
const games: Game[] = JSON.parse(
  readFileSync("public/data/games.json", "utf8"),
);
const analysis: {
  lessons: Lesson[];
  records: AnalysisRecord[];
  recentGameIds: string[];
} = JSON.parse(readFileSync("public/data/analysis.json", "utf8"));
describe("source integrity", () => {
  it("replays and deduplicates all actual PGNs", () => {
    const parsed = parseGames(readFileSync("data/all_chess_games.pgn", "utf8"));
    expect(parsed.errors).toEqual([]);
    expect(parsed.username).toBe("Frankrolewicz");
    expect(parsed.games).toHaveLength(1049);
    expect(parsed.duplicates).toBe(0);
    expect(summarize(parsed.games).currentRating).toBe(765);
  }, 30000);
  it("rejects unfinished, malformed and illegal games", () => {
    expect(
      parseGames(
        games[0].pgn
          .replaceAll("1-0", "*")
          .replaceAll("0-1", "*")
          .replaceAll("1/2-1/2", "*"),
      ).games,
    ).toHaveLength(0);
    expect(
      parseGames(
        '[Event "Test"]\n[Date "2026.11.10"]\n[White "Frankrolewicz"]\n[Black "Test"]\n[Result "1-0"]\n\n1. e5 1-0',
      ).errors.length,
    ).toBeGreaterThan(0);
    expect(parseGames("{\\rtf1 invalid}").errors.length).toBeGreaterThan(0);
  });
  it("keeps other users out and removes duplicate games", () => {
    expect(parseGames(games[0].pgn, "stranger").games).toHaveLength(0);
    expect(parseGames(games[0].pgn + "\n\n" + games[0].pgn).duplicates).toBe(1);
  });
  it("separates rapid ratings from blitz", () => {
    const blitz = { ...games[0], rapid: false, rating: 2500 };
    expect(summarize([...games, blitz]).peakRating).toBe(964);
  });
});
describe("verified teaching evidence", () => {
  it("covers exactly the most recent 150 plus 30 older comparison games", () => {
    expect(analysis.records).toHaveLength(180);
    expect(analysis.recentGameIds).toEqual(
      games
        .filter((g) => g.rapid)
        .slice(-150)
        .map((g) => g.id),
    );
    expect(new Set(analysis.records.map((r) => r.id)).size).toBe(180);
  });
  it("every lesson matches its actual game and both legal engine continuations", () => {
    const byId = new Map(games.map((g) => [g.id, g]));
    for (const l of analysis.lessons) {
      const game = byId.get(l.gameId)!;
      const c = new Chess();
      c.loadPgn(game.pgn);
      const move = c.history({ verbose: true })[l.ply];
      expect(move.before).toBe(l.fen);
      expect(move.lan).toBe(l.played);
      expect(move.color).toBe(l.color);
      expect(l.before.cp).toBeGreaterThanOrEqual(-400);
      expect(l.loss).toBeGreaterThanOrEqual(140);
      expect(l.before.depth).toBeGreaterThanOrEqual(12);
      expect(l.after.depth).toBeGreaterThanOrEqual(12);
      expect(l.before.best).not.toBe(l.played);
      for (const [fen, pv] of [
        [l.fen, l.before.pv],
        [move.after, l.after.pv],
      ] as const) {
        const replay = new Chess(fen);
        for (const uci of pv) expect(playUci(replay, uci)).toBeTruthy();
      }
    }
  }, 30000);
  it("normalizes cp and mate scores from side-to-move", () => {
    expect(
      parseInfo("info depth 12 score cp -45 nodes 120 pv e2e4 e7e5")?.cp,
    ).toBe(-45);
    expect(parseInfo("info depth 14 score mate -3 pv e1f1")?.mate).toBe(-3);
    expect(
      parseInfo("info depth 12 score cp 50 lowerbound pv e2e4"),
    ).toBeNull();
  });
  it("serializes UCI requests and discards stale search info", async () => {
    let count = 0;
    const t: Transport = {
      onmessage: null,
      onerror: null,
      terminate() {},
      postMessage(command) {
        queueMicrotask(() => {
          if (command === "uci") t.onmessage?.({ data: "uciok" });
          if (command === "isready") t.onmessage?.({ data: "readyok" });
          if (command.startsWith("go")) {
            count++;
            t.onmessage?.({
              data: `info depth 12 score cp ${count * 10} pv e2e4 e7e5`,
            });
            t.onmessage?.({ data: "bestmove e2e4" });
          }
        });
      },
    };
    const e = new Engine(t);
    const result = await Promise.all([
      e.evaluate(new Chess().fen()),
      e.evaluate(new Chess().fen()),
    ]);
    expect(result.map((r) => r.cp)).toEqual([10, 20]);
    e.close();
    await expect(e.evaluate(new Chess().fen())).rejects.toThrow("stopped");
  });
});
describe("spaced repetition", () => {
  it("retries misses in ten minutes and grows successful intervals", () => {
    const r = scheduleReview(undefined, "x", 1, 1000);
    expect(r.due).toBe(601000);
    expect(r.lapses).toBe(1);
    const success = scheduleReview(r, "x", 5, r.due);
    expect(success.interval).toBe(1);
    const next = scheduleReview(success, "x", 5, success.due);
    expect(next.interval).toBe(2.5);
    expect(scheduleReview(next, "x", 2, 1000).successes).toBe(0);
  });
  it("does not award mastery for repeated early reviews", () => {
    const first = scheduleReview(undefined, "x", 5, 1000);
    expect(scheduleReview(first, "x", 5, 2000).successes).toBe(1);
  });
  it("does not schedule future reviews, and prioritizes due cards", () => {
    const lessons = analysis.lessons.slice(0, 3);
    const future = scheduleReview(undefined, lessons[0].id, 5, 1000);
    const due = scheduleReview(undefined, lessons[1].id, 1, 0);
    const q = chooseLessons(lessons, [future, due], games, 700000);
    expect(q[0].id).toBe(due.id);
    expect(q.some((l) => l.id === future.id)).toBe(false);
  });
});
describe("IndexedDB persistence", () => {
  beforeEach(async () => {
    const d = await db();
    for (const store of [
      "games",
      "lessons",
      "reviews",
      "sessions",
      "analysis",
      "settings",
    ] as const)
      await d.clear(store);
  });
  it("deduplicates imports even when Chess.com changes header timestamps", async () => {
    await importPgn(games[0].pgn);
    const second = await importPgn(
      games[0].pgn.replace(/\[EndTime "[^"]+"\]/, '[UTCTime "12:00:00"]'),
    );
    expect(second.added).toBe(0);
    expect((await snapshot()).games).toHaveLength(1);
  });
  it("atomically records reviews and session scores", async () => {
    const review = scheduleReview(undefined, "x", 5);
    await recordAttempt(review, true);
    const state = await snapshot();
    expect(state.reviews[0].id).toBe("x");
    expect(state.sessions[0]).toEqual({
      day: dayKey(),
      seconds: 0,
      attempts: 1,
      correct: 1,
    });
  });
  it("rejects unsupported backups", async () => {
    await expect(restoreBackup('{"version":20}')).rejects.toThrow(
      "Unsupported",
    );
  });
});
