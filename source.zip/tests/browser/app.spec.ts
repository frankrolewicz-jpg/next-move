import { test, expect } from "@playwright/test";
import { readFileSync } from "node:fs";
const analysis = JSON.parse(readFileSync("public/data/analysis.json", "utf8"));
test("mobile: real lessons, hints, engine, persistence, offline cache and layout", async ({
  page,
  context,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto("./");
  await expect(
    page.getByRole("heading", { name: "Your next move starts here." }),
  ).toBeVisible();
  await expect(page.getByText("765", { exact: true })).toBeVisible();
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= window.innerWidth,
    ),
  ).toBe(true);
  await page.screenshot({
    path: "test-results/mobile-today.png",
    fullPage: true,
  });
  await page.getByRole("button", { name: "Start today’s session" }).click();
  await expect(
    page.getByRole("heading", { name: "What would you play?" }),
  ).toBeVisible();
  await expect(
    page.getByRole("button", { name: "Show explanation" }),
  ).toBeDisabled();
  await page.getByRole("button", { name: "Give me a hint" }).click();
  const lessonId = await page
    .locator("[data-lesson-id]")
    .getAttribute("data-lesson-id");
  const lesson = analysis.lessons.find((l: any) => l.id === lessonId);
  expect(lesson).toBeTruthy();
  await page.getByLabel("Enter a move").fill(lesson.playedSan);
  await page.getByRole("button", { name: "Try move" }).click();
  await expect(page.locator(".feedback")).toContainText("gives up too much", {
    timeout: 60000,
  });
  await page.getByLabel("Enter a move").fill(lesson.bestSan);
  await page.getByRole("button", { name: "Try move" }).click();
  await expect(
    page.getByRole("heading", { name: lesson.theme, exact: true }),
  ).toBeVisible();
  await expect(
    page.getByText("Legal continuation checked by chess.js"),
  ).toBeVisible();
  await page.getByRole("button", { name: "Next move", exact: true }).click();
  await expect(page.locator(".replay-controls")).toContainText("1 /");
  await page.screenshot({
    path: "test-results/mobile-lesson.png",
    fullPage: true,
  });
  await page.reload();
  await expect(
    page.getByRole("heading", { name: "Your next move starts here." }),
  ).toBeVisible();
  const reviews = await page.evaluate(async () => {
    return new Promise<number>((resolve) => {
      const r = indexedDB.open("chess-coach");
      r.onsuccess = () => {
        const q = r.result
          .transaction("reviews")
          .objectStore("reviews")
          .count();
        q.onsuccess = () => resolve(q.result);
      };
    });
  });
  expect(reviews).toBe(1);
  await page.evaluate(() => navigator.serviceWorker.ready);
  await expect(page.getByText("Offline ready", { exact: true })).toBeVisible();
  await context.setOffline(true);
  await page.reload();
  await expect(
    page.getByRole("heading", { name: "Your next move starts here." }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Start today’s session" }).click();
  await expect(
    page.getByRole("heading", { name: "What would you play?" }),
  ).toBeVisible();
  // Exercise the WASM worker while offline by checking an original mistake.
  const offId = await page
    .locator("[data-lesson-id]")
    .getAttribute("data-lesson-id");
  const offLesson = analysis.lessons.find((l: any) => l.id === offId);
  await page.getByLabel("Enter a move").fill(offLesson.playedSan);
  await page.getByRole("button", { name: "Try move" }).click();
  await expect(page.locator(".feedback")).toContainText("gives up too much", {
    timeout: 60000,
  });
  expect(errors).toEqual([]);
});
test("games: import rejects live games and duplicate imports; install dialog", async ({
  page,
}) => {
  await page.goto("./");
  await expect(
    page.getByRole("heading", { name: "Your next move starts here." }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "My games", exact: true })
    .last()
    .click();
  await expect(
    page.getByRole("heading", { name: "Your games, in one place." }),
  ).toBeVisible();
  await page
    .locator("input[type=file]")
    .first()
    .setInputFiles("data/all_chess_games.pgn");
  await expect(page.locator(".notice")).toContainText(
    "1049 duplicates skipped",
    { timeout: 60000 },
  );
  const pgn =
    '[Event "Live"]\n[White "Frankrolewicz"]\n[Black "test"]\n[Date "2026.11.10"]\n[Result "*"]\n\n1. e4 e5 *';
  await page
    .locator("input[type=file]")
    .first()
    .setInputFiles({
      name: "live.pgn",
      mimeType: "application/x-chess-pgn",
      buffer: Buffer.from(pgn),
    });
  await expect(page.locator(".notice")).toContainText("1 rejected");
  await page.getByRole("button", { name: "Install on iPhone" }).click();
  await expect(page.getByRole("dialog")).toContainText("Add to Home Screen");
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= window.innerWidth,
    ),
  ).toBe(true);
});
test("desktop layout and progress", async ({ page }) => {
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.goto("./");
  await expect(
    page.getByRole("heading", { name: "Your next move starts here." }),
  ).toBeVisible();
  await page.screenshot({
    path: "test-results/desktop-today.png",
    fullPage: true,
  });
  await page
    .getByRole("button", { name: "Progress", exact: true })
    .first()
    .click();
  await expect(
    page.getByRole("heading", { name: "Your rapid rating history" }),
  ).toBeVisible();
  await expect(page.getByText("964", { exact: false }).first()).toBeVisible();
});
test("completed-game sync handles success, duplicates and network failure", async ({
  page,
}) => {
  const games = JSON.parse(readFileSync("public/data/games.json", "utf8"));
  const existing = games.at(-1);
  const month = new Date().toISOString().slice(0, 7).replace("-", "/");
  const root = "https://api.chess.com/pub/player/frankrolewicz/games/";
  let failed = false;
  await page.route("https://api.chess.com/**", (route) => {
    if (failed) return route.abort("failed");
    if (route.request().url().endsWith("/archives"))
      return route.fulfill({ json: { archives: [root + month] } });
    return route.fulfill({
      json: {
        games: [
          {
            rules: "chess",
            end_time: Math.floor(Date.now() / 1000) - 10,
            pgn: existing.pgn,
          },
        ],
      },
    });
  });
  await page.goto("./");
  await expect(
    page.getByRole("heading", { name: "Your next move starts here." }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "My games", exact: true })
    .last()
    .click();
  await page.getByRole("button", { name: "Sync games", exact: true }).click();
  await expect(page.locator(".notice")).toContainText(
    "0 new completed games imported.",
  );
  await page.getByRole("button", { name: "Dismiss notice" }).click();
  failed = true;
  await page.getByRole("button", { name: "Sync games", exact: true }).click();
  await expect(page.locator(".notice")).toContainText("Sync unavailable");
  await expect(
    page.getByRole("button", { name: "Import PGN", exact: true }),
  ).toBeEnabled();
  failed = false;
  await page.getByRole("checkbox", { name: /Check for new games/ }).check();
  await expect(page.locator(".notice")).toContainText("Already checked");
  await page.evaluate(async () => {
    await new Promise<void>((resolve, reject) => {
      const request = indexedDB.open("chess-coach");
      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        const transaction = request.result.transaction("settings", "readwrite");
        transaction.objectStore("settings").put(0, "lastSync");
        transaction.oncomplete = () => resolve();
      };
    });
    document.dispatchEvent(new Event("visibilitychange"));
  });
  await expect(page.locator(".notice")).toContainText(
    "0 new completed games imported.",
  );
});
test("board supports touch-style square selection", async ({ page }) => {
  await page.goto("./");
  await expect(
    page.getByRole("heading", { name: "Your next move starts here." }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Start today’s session" }).click();
  const id = await page
    .locator("[data-lesson-id]")
    .getAttribute("data-lesson-id");
  const lesson = analysis.lessons.find((l: any) => l.id === id);
  await page.locator(`[data-square="${lesson.best.slice(0, 2)}"]`).click();
  await page.locator(`[data-square="${lesson.best.slice(2, 4)}"]`).click();
  await expect(
    page.getByRole("heading", { name: lesson.theme, exact: true }),
  ).toBeVisible();
});
