# Chess Coach: architecture and delivery plan

## Source validation first

The supplied file is RTF, not PGN. Preserve `data/all_chess_games.rtf`; convert it with macOS textutil into `data/all_chess_games.pgn`. Replay every game through chess.js, check completed results, infer the shared username, deduplicate by players/date/time/control/result/start position/moves, sort chronologically, and export rating history. Date ordering within a day uses EndTime where UTC time is absent; ratings are header ratings, not a live account lookup.

## Local-first architecture

- React + TypeScript + Vite, static files compatible with Cloudflare Pages. No functions, database server, accounts, secrets, or paid services.
- chess.js is the authority for legal moves and deterministic board facts; react-chessboard renders touch/click/drag input.
- Single-thread Stockfish WASM in a dedicated Web Worker avoids SharedArrayBuffer requirements on iPhone. UCI requests are serialized, bounded, and cancellable by terminating the worker. Analysis is explicitly limited to imported completed games; there is no arbitrary-position analysis entry point or live game endpoint.
- IndexedDB stores validated games, verified lessons, per-game analysis completion, review schedules and daily sessions. A bundled seed supplies historical games and engine-verified lessons on first launch. JSON backup/restore protects against browser storage eviction.
- A service worker caches the app, local engine, and history for offline use. App manifest and PNG icons support iPhone home-screen installation over HTTPS.
- Chess.com public monthly archives are read sequentially while the app is open. Only completed standard games are accepted. Local PGN import remains available if CORS/network/rate limiting prevents sync. No background promises when iOS closes the app.

## Teaching evidence

Current priorities use the latest 150 rapid games. Historical rating cohorts measure progress independently of engine coverage. Scan every player move in those games, compare best-play and played-move evaluations, then recheck candidate mistakes at greater depth. Store engine version/depth, FEN, actual move, best move and legal principal variations. Deterministic labels only: missed mate, allowed mate, immediate material loss, missed capture, opening decision, endgame decision or calculation. Do not invent pins/forks/strategic diagnoses from centipawn loss alone. Explain the concrete legal continuation and score change. Report sample sizes and engine depth; finite search is evidence, not a proof of a unique answer.

## MVP milestones

1. Validate source and publish local data report and rating CSV.
2. Build engine adapter and shared evidence/lesson pipeline; precompute recent-game coverage and representative older cohorts.
3. Implement dashboard, history, interactive lesson attempt → escalating hints → verified explanation and replay, adaptive review scheduling and an approximately 20-minute session (3 minutes review, 12 minutes focus, 5 minutes recall).
4. Add import/sync, persistence, backup, offline/install UI, engine analysis progress and cancellation.
5. Run unit tests for parsing, legal evidence, score orientation, scheduling and persistence; browser tests for actual WASM, lessons, reload/offline and mobile layout; TypeScript and production build.
6. Keep deployment separate until local validation passes. Prepare Cloudflare Pages instructions; do not provision paid resources.

## Later improvements

Deeper tactical motifs with explicit proof, multi-move opponent responses, improved alternative-move acceptance, and broader strategic analysis require additional verified rules. Elo 1400 is a training goal, not a promised outcome. No LLM-generated explanations or paid inference.
