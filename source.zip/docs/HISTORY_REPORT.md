# Frankrolewicz — historical assessment

## Validated source

The supplied file was `data/all_chess_games.rtf`, not PGN. The original is preserved; macOS textutil extracted plain text into `data/all_chess_games.pgn`. chess.js replayed every move. 1049 records produced 1049 unique completed standard rapid games, with 0 duplicates and 0 errors. Every game includes Frankrolewicz.

Date range: February 19, 2022–November 10, 2026. Header ratings: first 785, latest 765, peak 964. These are recorded ratings at game time, not a current account lookup or guaranteed post-game ratings. Games without UTC start times are ordered using EndTime; same-day ordering may be imperfect around midnight.

## Performance changes

| Cohort                   | Average rating | Wins | Losses | Draws | Score rate |
| ------------------------ | -------------: | ---: | -----: | ----: | ---------: |
| Previous 150 rapid games |            733 |   80 |     66 |     4 |        55% |
| Latest 150 rapid games   |            789 |   69 |     70 |    11 |        50% |

Your recent playing level averages 56 points higher, but your score rate has not improved. This suggests a higher rating baseline with continued inconsistency; it does not establish a cause. The full history is not a steady upward trajectory: the 964 peak occurred on November 20, 2024, followed by a low of 482 on January 23, 2026. The recent 789 average indicates recovery from that low but remains below the earlier peak. Gaps in play and the small 2024 sample make year-to-year comparisons imperfect.

| Year | Games | Average rating | Rating range |
| ---- | ----: | -------------: | -----------: |
| 2022 |    11 |            667 |      582–785 |
| 2023 |   358 |            708 |      570–880 |
| 2024 |    25 |            929 |      867–964 |
| 2025 |     9 |            878 |      818–923 |
| 2026 |   646 |            668 |      482–853 |

## Verified lesson evidence

Stockfish 17.1 lite single-threaded screened 5584 player decisions in all 150 recent rapid games and 30 evenly spaced older games. Terminal positions were skipped. Screening depth: 8; verification depth: 12. Up to three high-loss candidates per game were rechecked. Each retained lesson loses at least 1.4 pawn-equivalents relative to best play; positions already worse than -4.0 were excluded. Mate scores use a separate large ordering value, not a literal pawn count.

362 lessons survived verification: 305 recent and 57 older. All source positions and full stored principal variations are legally replayed by tests. Finite-depth search is not proof of a unique best move.

| Theme                   | Recent lessons | Recent games / 150 | Older sample lessons | Older sample games / 30 |
| ----------------------- | -------------: | -----------------: | -------------------: | ----------------------: |
| Calculation             |             84 |                 62 |                   17 |                      15 |
| Material under threat   |             66 |                 56 |                   18 |                      16 |
| Missed capture          |             54 |                 44 |                    9 |                       7 |
| King safety             |             30 |                 27 |                    1 |                       1 |
| Opening decisions       |             24 |                 21 |                    4 |                       4 |
| Missed mate             |             16 |                 14 |                    3 |                       2 |
| Open-file rook activity |             14 |                 13 |                    2 |                       2 |
| Endgame decisions       |             13 |                 10 |                    0 |                       0 |
| Piece development       |              4 |                  4 |                    3 |                       3 |

These counts describe a capped selection of teaching positions, not all blunders or their true frequency. The older sample is small and covers several years; do not interpret raw counts as a statistically controlled improvement measurement. The app uses all historical ratings for the reliable performance comparison and weights only the latest 150 games for current lesson priorities.

## Teaching priorities

1. Before committing a move, name your opponent's strongest check or capture. Verified material-loss examples require a net material deficit in the displayed continuation; an equal exchange is not labeled a material-loss tactic.
2. Compare at least two candidates, calculate a forcing reply, and check the resulting position again. “Calculation” is a general decision label, not an invented fork/pin diagnosis.
3. Search checks and captures before quiet moves, including mating continuations.
4. In selected strategic lessons, develop a minor piece from its starting square or use a pawn-free file with a rook only when those facts are present and Stockfish prefers the move. Other opening/endgame labels describe phase only.

## Examples from actual games

### Calculation

2026-10-27, against Drenzer5, playing White, move 32.

You played a4. Stockfish prefers Rh5. Compare your opponent's strongest reply to each candidate. From your side, the evaluation changes from 0.00 pawns to -2.89 pawns after your move. The lines below show the engine's best replies at depth 12; they are continuations, not a prediction of what your opponent played.

- Preferred line: Rh5 Bg3 Rxh7+ Kd6 Rf1 a5
- After a4: Bc5 Rxc5 bxc5 Re5 Kd6 Rh5
- Position: `8/p2k3p/1p1bb3/1R6/2Pr4/1P5P/P5P1/4R1K1 w - - 0 32`
- Evidence ID: `6e33c4d0-62`

### Material under threat

2026-10-21, against Motorola94, playing Black, move 5.

You played Nf6. Stockfish prefers Nc6. The engine's reply Qxa5 captures your knight. In the displayed continuation your material balance falls by 3 points (pawn 1, minor piece 3, rook 5, queen 9). From your side, the evaluation changes from -0.15 pawns to -3.21 pawns after your move. The lines below show the engine's best replies at depth 12; they are continuations, not a prediction of what your opponent played.

- Preferred line: Nc6 Bc4 Qe7 Nc3 Nf6 Qd1
- After Nf6: Qxa5 b6 Qe5+ Be7 Nc3 O-O
- Position: `r1bqkbnr/pppp1ppp/8/n2Q4/4P3/8/PPP2PPP/RNB1KBNR b KQkq - 4 5`
- Evidence ID: `ec032c6-9`

### Missed capture

2026-11-05, against archivel07, playing White, move 23.

You played Qc6. Stockfish prefers Qxa8. Qxa8 captures a rook. From your side, the evaluation changes from 0.01 pawns to -5.10 pawns after your move. The lines below show the engine's best replies at depth 12; they are continuations, not a prediction of what your opponent played.

- Preferred line: Qxa8 Qxa8 Bxa8 Re2 Bd5 g6
- After Qc6: Rb8 Rc1 Kf8 Be4 Be5 Qc5
- Position: `r2q2k1/pQ2rppp/5b2/3B4/8/3P4/P4PPP/5RK1 w - - 1 23`
- Evidence ID: `f797b170-44`

### King safety

2026-10-21, against dancanzz, playing Black, move 26.

You played Qh5. Stockfish prefers Qg4+. Qg4+ gives check. From your side, the evaluation changes from 0.00 pawns to being mated in 2 after your move. The lines below show the engine's best replies at depth 12; they are continuations, not a prediction of what your opponent played.

- Preferred line: Qg4+ Kh1 Qf3+ Kg1
- After Qh5: Qxf8+ Kxf8 Rc8#
- Position: `5rk1/p3Qppp/8/8/1P1p4/P4q2/2R2P1P/4R1K1 b - - 1 26`
- Evidence ID: `59b2a065-51`

### Opening decisions

2026-10-27, against burlychesselephant, playing Black, move 7.

You played d5. Stockfish prefers Na5. Compare your opponent's strongest reply to each candidate. From your side, the evaluation changes from -0.24 pawns to -1.69 pawns after your move. The lines below show the engine's best replies at depth 12; they are continuations, not a prediction of what your opponent played.

- Preferred line: Na5 Qd2 O-O Bg5 Nxc4 dxc4
- After d5: Nxd5 Nxd5 Bxd5 Bd6 Bxc6+ bxc6
- Position: `r1bqk2r/ppp1bppp/2np1n2/8/2B1PB2/2NP1N2/PPP3PP/R2QK2R b KQkq - 1 7`
- Evidence ID: `e089f98c-13`

### Missed mate

2026-11-10, against Reochesschamp, playing White, move 29.

You played Qe5+. Stockfish prefers Rhe1+. Rhe1+ gives check. From your side, the evaluation changes from a forced mate in 8 to 8.17 pawns after your move. The lines below show the engine's best replies at depth 12; they are continuations, not a prediction of what your opponent played.

- Preferred line: Rhe1+ Kf6 Qe5+ Kf7 Qe7+ Kg8
- After Qe5+: Kf7 Qd5+ Ke7 Rae1+ Kd8 Ne6+
- Position: `7r/ppQbk1pp/q7/1N6/2PP1N2/3K4/P4PPP/R6R w - - 11 29`
- Evidence ID: `19547efe-56`

## Daily practice

Spend about three minutes recalling due positions, twelve minutes attempting recent weaknesses, and five minutes explaining the threat and replaying alternatives. Try before revealing. Hints reduce the review grade; failed or revealed cards return in ten minutes. Successful reviews begin at one day, grow to a maximum of thirty days, and require three spaced successes for mastery. Early manual revisits do not earn additional mastery. Priority rises with recent-game frequency and practice lapses.

This is a training plan toward 1400, not a predicted or guaranteed rating gain.
