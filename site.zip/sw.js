const PREFIX='next-move-'+new URL(self.registration.scope).pathname+'-';
const CACHE=PREFIX+'9e453f53a186';
const ASSETS=["assets/index-CNxHDsKX.js","assets/index-Dd2x5W9M.css","data/analysis.json","data/games.json","data/profile.json","engine/COPYING.txt","engine/SOURCE.txt","engine/stockfish.js","engine/stockfish.wasm","icons/icon-192.png","icons/icon-512.png","index.html","manifest.webmanifest"].map(path=>new URL(path,self.registration.scope).href);
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS))));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith(PREFIX)&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{const url=new URL(event.request.url);if(event.request.method!=='GET'||url.origin!==self.location.origin)return;event.respondWith(caches.open(CACHE).then(cache=>cache.match(event.request.mode==='navigate'?new URL('index.html',self.registration.scope).href:event.request,{ignoreVary:true}).then(cached=>cached||fetch(event.request))));});
